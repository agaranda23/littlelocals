import React, { useState, useEffect, useMemo } from "react";
import { createClient } from "@supabase/supabase-js";
import { FALLBACK_LISTINGS } from "./fallbackListings";
import { typeColors } from "./typeColors";
import { getDistanceMiles } from "./utils";
import { BrandBear, SceneBg, isOnToday, isOnDay, shareWhatsApp, MapView, ListingCard, DetailView } from "./components";

let supabase = null;
try {
  supabase = createClient(
    "https://xcpabhbqiohnqxihtjbo.supabase.co",
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhjcGFiaGJxaW9obnF4aWh0amJvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDAwNzA2MTksImV4cCI6MjA1NTY0NjYxOX0.djDSmMGNsCKOR9Cf9fBB0-xsZnJoYvzFwJaf0jdSPMQ"
  );
} catch(e) {
  console.log("Supabase init failed:", e);
}

function WestLondonListings() {
  const [listings, setListings] = useState(FALLBACK_LISTINGS);
  const [selected, setSelected] = useState(null);
  const [showInstallBanner, setShowInstallBanner] = useState(() => {
    try { return !localStorage.getItem("ll_install_dismissed"); } catch(e) { return true; }
  });
  const [isLoading, setIsLoading] = useState(true);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [pullRefreshing, setPullRefreshing] = useState(false);
  const [installPrompt, setInstallPrompt] = useState(null);

  // Capture Chrome's install prompt
  useEffect(() => {
    const handler = (e) => { e.preventDefault(); setInstallPrompt(e); };
    window.addEventListener("beforeinstallprompt", handler);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);
  const [typeFilter, setTypeFilter] = useState("All Types");
  const [areaFilter, setAreaFilter] = useState(() => {
    try {
      const areaChips = ["Ealing", "Ruislip", "Eastcote", "Uxbridge"];
      const norm = s => s.trim().toLowerCase().replace(/['']/g, "").replace(/\s+/g, " ");
      const areaMap = {};
      areaChips.forEach(a => { areaMap[norm(a)] = a; });
      const raw = new URLSearchParams(window.location.search).get("area");
      if (!raw) return "Ealing";
      const match = areaMap[norm(raw)];
      if (match) return match;
      // No match — clean the bad param
      const url = new URL(window.location); url.searchParams.delete("area"); window.history.replaceState({}, "", url);
      return "Ealing";
    } catch(e) { return "Ealing"; }
  });
  const [freeOnly, setFreeOnly] = useState(false);
  const [search, setSearch] = useState("");
  const [userLoc, setUserLoc] = useState(null);
  const [locStatus, setLocStatus] = useState("idle");
  const [isSunny, setIsSunny] = useState(true);
  const [dayFilter, setDayFilter] = useState("today");
  const [weatherMode, setWeatherMode] = useState("all");
  const [napFilter, setNapFilter] = useState("all");
  const [page, setPage] = useState(1);
  const [mapView, setMapView] = useState(false);
  const [sortBy, setSortBy] = useState("mixed");
  const ITEMS_PER_PAGE = 6;
  const [cityFilter, setCityFilter] = useState(() => {
    try { return localStorage.getItem("ll_city") || "All"; } catch(e) { return "All"; }
  });
  const [reviews, setReviews] = useState([]);
  const [favourites, setFavourites] = useState(() => {
    try { const s = localStorage.getItem("ll_favs"); return s ? JSON.parse(s) : []; } catch(e) { return []; }
  });
  const [passport, setPassport] = useState(() => {
    try { const s = localStorage.getItem("ll_passport"); return s ? JSON.parse(s) : []; } catch(e) { return []; }
  });
  const [showFavourites, setShowFavourites] = useState(false);
  const [showCalendar, setShowCalendar] = useState(false);
  const [showMoreFilters, setShowMoreFilters] = useState(false);
  const [calendarPlan, setCalendarPlan] = useState(() => {
    try { const s = localStorage.getItem("ll_calendar_v2"); return s ? JSON.parse(s) : {}; } catch(e) { return {}; }
  });
  const [showSuggest, setShowSuggest] = useState(false);
  const [suggestForm, setSuggestForm] = useState({ name: "", type: "Soft Play", city: "London", location: "", venue: "", ages: "", day: "", time: "", price: "", description: "", submitterName: "", submitterEmail: "" });
  const [suggestedActivities, setSuggestedActivities] = useState([]);
  const [suggestSubmitted, setSuggestSubmitted] = useState(false);
  const [shareCopied, setShareCopied] = useState(false);

  // Load from Supabase on mount (localStorage fallback)
  useEffect(() => {
    // Fetch weather for Ealing (Open-Meteo, no API key needed)
    fetch("https://api.open-meteo.com/v1/forecast?latitude=51.513&longitude=-0.309&current=weather_code&timezone=Europe/London")
      .then(function(r) { return r.json(); })
      .then(function(d) {
        if (d && d.current && d.current.weather_code !== undefined) {
          // WMO codes: 0-3 = clear/partly cloudy, 45-48 = fog, 51+ = rain/snow
          var sunny = d.current.weather_code <= 3;
          setIsSunny(sunny);
          console.log("Weather code:", d.current.weather_code, "Sunny:", sunny);
        }
      })
      .catch(function(e) { console.log("Weather fetch failed, defaulting to sunny"); });
    (async () => {
      if (!supabase) { console.log("No Supabase client, using fallback"); return; }
      try {
        // Load listings from Supabase
        const { data: ld, error: listErr } = await supabase.from("listings").select("*").order("id", { ascending: true }).limit(500);
        console.log("Listings loaded:", ld ? ld.length : 0, "error:", listErr);
        if (ld && ld.length > 0) {
          setListings(ld.map(l => ({
            id: l.id, name: l.name, type: l.type, emoji: l.emoji,
            location: l.location, venue: l.venue, lat: l.lat, lng: l.lng,
            ages: l.ages, day: l.day, time: l.time, price: l.price,
            free: l.free, indoor: l.indoor, description: l.description,
            bring: l.bring || [], sen: l.sen,
            cta: { type: l.cta_type, label: l.cta_label, url: l.cta_url },
            photos: l.photos, verified: l.verified, parking: l.parking,
            timeSlot: l.time_slot, createdAt: l.created_at,
          })));
          try { localStorage.setItem("ll_listings_cache", JSON.stringify(ld)); } catch(e) {}
        }
        // Load reviews
        const { data: rd } = await supabase.from("reviews").select("*").order("created_at", { ascending: false });
        if (rd) {
          setReviews(rd.map(r => ({ id: r.id, listingId: r.listing_id, name: r.reviewer_name, rating: r.rating, text: r.review_text, photos: r.photos || [], date: new Date(r.created_at).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }) })));
          try { localStorage.setItem("ll_reviews", JSON.stringify(rd)); } catch(e) {}
        }
        // Load suggestions
        const { data: sd } = await supabase.from("suggestions").select("*").order("created_at", { ascending: false });
        if (sd) setSuggestedActivities(sd.map(s => ({ ...s, submitterName: s.submitter_name, submittedAt: new Date(s.created_at).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }) })));
      } catch(e) {
        console.log("Supabase unavailable, trying local cache");
        try {
          const cachedListings = localStorage.getItem("ll_listings_cache");
          if (cachedListings) {
            const ld = JSON.parse(cachedListings);
            setListings(ld.map(l => ({
              id: l.id, name: l.name, type: l.type, emoji: l.emoji,
              location: l.location, venue: l.venue, lat: l.lat, lng: l.lng,
              ages: l.ages, day: l.day, time: l.time, price: l.price,
              free: l.free, indoor: l.indoor, description: l.description,
              bring: l.bring || [], sen: l.sen,
              cta: { type: l.cta_type, label: l.cta_label, url: l.cta_url },
              photos: l.photos, verified: l.verified, parking: l.parking,
              timeSlot: l.time_slot, createdAt: l.created_at,
            })));
          }
        } catch(e2) {}
        try { const sr = localStorage.getItem("ll_reviews"); if (sr) { const rd = JSON.parse(sr); setReviews(rd.map(r => ({ id: r.id, listingId: r.listing_id || r.listingId, name: r.reviewer_name || r.name, rating: r.rating, text: r.review_text || r.text, photos: r.photos || [], date: r.date || new Date(r.created_at).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }) }))); } } catch(e2) {}
        try { const ss = localStorage.getItem("ll_suggestions"); if (ss) setSuggestedActivities(JSON.parse(ss)); } catch(e2) {}
      }
      setIsLoading(false);
    })();
  }, []);

  // Browser back button support — prevents closing app
  useEffect(() => {
    const handlePop = () => {
      if (selected) { setSelected(null); return; }
      if (showCalendar) { setShowCalendar(false); return; }
      if (showSuggest) { setShowSuggest(false); return; }
    };
    window.addEventListener("popstate", handlePop);
    return () => window.removeEventListener("popstate", handlePop);
  }, [selected, showCalendar, showSuggest]);

  // Push history state when opening views
  const openDetail = (item) => { window.history.pushState({ view: "detail" }, ""); setSelected(item); window.scrollTo(0, 0); };
  const openCalendar = () => { window.history.pushState({ view: "calendar" }, ""); setShowCalendar(true); };
  const openSuggest = () => { window.history.pushState({ view: "suggest" }, ""); setShowSuggest(true); };

  const closeDetail = () => { if (window.history.state?.view) window.history.back(); else setSelected(null); };
  const closeCalendar = () => { if (window.history.state?.view) window.history.back(); else setShowCalendar(false); };
  const closeSuggest = () => { if (window.history.state?.view) window.history.back(); else setShowSuggest(false); };

  // Scroll to top button visibility
  useEffect(() => {
    const onScroll = () => setShowScrollTop(window.scrollY > 400);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Pull to refresh
  const refreshData = async () => {
    if (!supabase || pullRefreshing) return;
    setPullRefreshing(true);
    try {
      const { data: ld } = await supabase.from("listings").select("*").order("id", { ascending: true }).limit(500);
      if (ld && ld.length > 0) {
        setListings(ld.map(l => ({
          id: l.id, name: l.name, type: l.type, emoji: l.emoji,
          location: l.location, venue: l.venue, lat: l.lat, lng: l.lng,
          ages: l.ages, day: l.day, time: l.time, price: l.price,
          free: l.free, indoor: l.indoor, description: l.description,
          bring: l.bring || [], sen: l.sen,
          cta: { type: l.cta_type, label: l.cta_label, url: l.cta_url },
          photos: l.photos, verified: l.verified, parking: l.parking,
          timeSlot: l.time_slot, createdAt: l.created_at,
        })));
      }
      const { data: rd } = await supabase.from("reviews").select("*").order("created_at", { ascending: false });
      if (rd) setReviews(rd.map(r => ({ id: r.id, listingId: r.listing_id, name: r.reviewer_name, rating: r.rating, text: r.review_text, photos: r.photos || [], date: new Date(r.created_at).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }) })));
    } catch(e) {}
    setPullRefreshing(false);
  };

  // Backup to localStorage
  useEffect(() => { try { localStorage.setItem("ll_city", cityFilter); } catch(e) {} }, [cityFilter]);
  useEffect(() => { try { localStorage.setItem("ll_reviews", JSON.stringify(reviews)); } catch(e) {} }, [reviews]);
  useEffect(() => { try { localStorage.setItem("ll_suggestions", JSON.stringify(suggestedActivities)); } catch(e) {} }, [suggestedActivities]);

  // Sync area filter to URL
  useEffect(() => {
    try {
      const url = new URL(window.location);
      if (areaFilter !== "All Areas") { url.searchParams.set("area", areaFilter); } else { url.searchParams.delete("area"); }
      window.history.replaceState({}, "", url);
    } catch(e) {}
  }, [areaFilter]);

  // Reset to page 1 when any filter changes
  useEffect(() => { setPage(1); }, [cityFilter, typeFilter, areaFilter, freeOnly, search, dayFilter, weatherMode, napFilter]);

  // Persist favourites
  useEffect(() => { try { localStorage.setItem("ll_favs", JSON.stringify(favourites)); } catch(e) {} }, [favourites]);
  useEffect(() => { try { localStorage.setItem("ll_passport", JSON.stringify(passport)); } catch(e) {} }, [passport]);
  useEffect(() => { try { localStorage.setItem("ll_calendar_v2", JSON.stringify(calendarPlan)); } catch(e) {} }, [calendarPlan]);

  const addToCalendar = (activityId, dateKey) => {
    if (navigator.vibrate) navigator.vibrate(10);
    setCalendarPlan(prev => {
      const day = prev[dateKey] || [];
      if (day.includes(activityId)) return prev;
      return { ...prev, [dateKey]: [...day, activityId] };
    });
  };

  const removeFromCalendar = (activityId, dateKey) => {
    setCalendarPlan(prev => {
      const updated = (prev[dateKey] || []).filter(id => id !== activityId);
      const newPlan = { ...prev, [dateKey]: updated };
      if (updated.length === 0) delete newPlan[dateKey];
      return newPlan;
    });
  };

  const calendarTotal = Object.values(calendarPlan).reduce((sum, arr) => sum + arr.length, 0);

  const toggleFavourite = (id) => {
    if (navigator.vibrate) navigator.vibrate(10);
    setFavourites(prev => prev.includes(id) ? prev.filter(f => f !== id) : [...prev, id]);
  };

  const togglePassport = (id) => {
    if (navigator.vibrate) navigator.vibrate(15);
    setPassport(prev => prev.includes(id) ? prev.filter(p => p !== id) : [...prev, id]);
  };

  const addReview = async (review) => {
    const temp = { ...review, id: Date.now(), date: new Date().toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }) };
    setReviews(prev => [temp, ...prev]);
    try {
      const { data } = await supabase.from("reviews").insert({ listing_id: review.listingId, reviewer_name: review.name, rating: review.rating, review_text: review.text, photos: review.images || review.photos || [] }).select().single();
      if (data) setReviews(prev => prev.map(r => r.id === temp.id ? { id: data.id, listingId: data.listing_id, name: data.reviewer_name, rating: data.rating, text: data.review_text, photos: data.photos || [], date: new Date(data.created_at).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }) } : r));
    } catch(e) {}
  };

  const submitSuggestion = async () => {
    if (!suggestForm.name.trim() || !suggestForm.venue.trim() || !suggestForm.submitterName.trim() || !suggestForm.location) return;
    const temp = { ...suggestForm, id: Date.now(), status: "pending", submittedAt: new Date().toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }) };
    setSuggestedActivities(prev => [...prev, temp]);
    try {
      await supabase.from("suggestions").insert({ name: suggestForm.name, type: suggestForm.type, city: suggestForm.city, location: suggestForm.location, venue: suggestForm.venue, ages: suggestForm.ages, day: suggestForm.day + (suggestForm.time ? " " + suggestForm.time : ""), price: suggestForm.price, description: suggestForm.description, submitter_name: suggestForm.submitterName, submitter_email: suggestForm.submitterEmail });
    } catch(e) {}
    setSuggestForm({ name: "", type: "Soft Play", city: "London", location: "", venue: "", ages: "", day: "", time: "", price: "", description: "", submitterName: "", submitterEmail: "" });
    setShowSuggest(false);
    setSuggestSubmitted(true);
    setTimeout(() => setSuggestSubmitted(false), 5000);
  };

  const requestLocation = () => {
    if (!navigator.geolocation) { setLocStatus("denied"); return; }
    setLocStatus("requesting");
    navigator.geolocation.getCurrentPosition(
      (pos) => { setUserLoc({ lat: pos.coords.latitude, lng: pos.coords.longitude }); setLocStatus("granted"); setSortBy("nearest"); setAreaFilter("All Areas"); setPage(1); },
      (err) => { console.log("Location error:", err.message); setLocStatus("denied"); },
      { enableHighAccuracy: false, timeout: 15000, maximumAge: 300000 }
    );
  };

// Smart search keywords — maps common search terms to activity types and specific listings
const searchKeywords = {
  // Dance & movement
  "dance": ["Music", "Performing Arts", "Sport"],
  "ballet": ["Performing Arts"],
  "street dance": ["Performing Arts"],
  "tap": ["Performing Arts"],
  "movement": ["Music", "Performing Arts"],
  "disco": ["Music", "Performing Arts"],
  // Arts & making
  "pottery": ["Arts & Crafts", "Baking"],
  "painting": ["Arts & Crafts", "Messy Play"],
  "ceramics": ["Arts & Crafts"],
  "drawing": ["Arts & Crafts"],
  "creative": ["Arts & Crafts", "Messy Play", "Baking"],
  "craft": ["Arts & Crafts", "Messy Play"],
  "art": ["Arts & Crafts", "Messy Play"],
  "make": ["Arts & Crafts", "Baking"],
  // Physical
  "trampoline": ["Sport"],
  "gymnastics": ["Sport"],
  "circus": ["Sport"],
  "climbing": ["Sport", "Outdoor"],
  "football": ["Sport"],
  "tennis": ["Sport", "Outdoor"],
  "jump": ["Sport"],
  "bounce": ["Soft Play", "Sport"],
  "active": ["Sport", "Soft Play", "Outdoor"],
  "exercise": ["Sport", "Swimming"],
  // Water
  "swim": ["Swimming"],
  "pool": ["Swimming"],
  "water": ["Swimming", "Messy Play", "Outdoor"],
  "splash": ["Swimming", "Outdoor"],
  // Nature & outdoors
  "park": ["Outdoor"],
  "garden": ["Outdoor"],
  "nature": ["Outdoor"],
  "walk": ["Outdoor"],
  "forest": ["Outdoor"],
  "woods": ["Outdoor"],
  "playground": ["Outdoor"],
  "picnic": ["Outdoor"],
  "animals": ["Outdoor"],
  "ducks": ["Outdoor"],
  "beach": ["Outdoor"],
  // Learning & development
  "sing": ["Music", "Story Time"],
  "song": ["Music", "Story Time"],
  "rhyme": ["Story Time", "Music"],
  "reading": ["Story Time"],
  "books": ["Story Time"],
  "library": ["Story Time"],
  "learn": ["Messy Play", "Story Time", "Performing Arts"],
  "educational": ["Messy Play", "Story Time"],
  // Social
  "baby group": ["Playgroup", "Music"],
  "toddler group": ["Playgroup"],
  "mum": ["Playgroup"],
  "parent": ["Playgroup"],
  "social": ["Playgroup", "Soft Play"],
  "friends": ["Playgroup", "Soft Play"],
  "drop in": ["Playgroup"],
  "free": ["Playgroup", "Outdoor"],
  // Sensory & messy
  "sensory": ["Messy Play", "Music", "Soft Play"],
  "messy": ["Messy Play"],
  "slime": ["Messy Play"],
  "paint": ["Messy Play", "Arts & Crafts"],
  "sand": ["Messy Play", "Outdoor"],
  "play dough": ["Messy Play", "Arts & Crafts"],
  // Food
  "cook": ["Baking"],
  "bake": ["Baking"],
  "cake": ["Baking"],
  "food": ["Baking"],
  // Needs
  "sen": ["Playgroup", "Swimming"],
  "disability": ["Playgroup", "Swimming"],
  "additional needs": ["Playgroup", "Swimming"],
  "accessible": ["Outdoor", "Playgroup"],
  // Entertainment
  "theatre": ["Performing Arts"],
  "drama": ["Performing Arts"],
  "acting": ["Performing Arts"],
  "show": ["Performing Arts", "Music"],
  "perform": ["Performing Arts"],
  "stage": ["Performing Arts"],
  // Play
  "soft play": ["Soft Play"],
  "ball pit": ["Soft Play"],
  "slide": ["Soft Play", "Outdoor"],
  "indoor play": ["Soft Play"],
  // Transport themed
  "train": ["Outdoor"],
  "railway": ["Outdoor"],
  "miniature": ["Outdoor"],
};

// City groupings for the city picker
const cityGroups = {
  "London": ["Acton", "Barnet", "Battersea", "Bethnal Green", "Brentford", "Brixton", "Camden", "Canary Wharf", "Chiswick", "Clapham", "Covent Garden", "Croydon", "Crystal Palace", "Dulwich", "Ealing", "Eastcote", "Edgware", "Feltham", "Finchley", "Forest Hill", "Greenford", "Greenwich", "Hackney", "Hammersmith", "Hampstead", "Hanwell", "Harrow", "Hayes", "Highgate", "Hillingdon", "Hounslow", "Ickenham", "Isleworth", "Islington", "Kensington", "Kew", "Lea Bridge", "Lewisham", "London Bridge", "Northolt", "Northwood", "Peckham", "Pinner", "Regent's Park", "Richmond", "Romford", "Ruislip", "Shepherd's Bush", "Silvertown", "South Kensington", "South Ruislip", "Southall", "Southwark", "Stanmore", "Stratford", "Twickenham", "Uxbridge", "Walthamstow", "Wembley", "Westminster", "Wimbledon", "Acton / Chiswick", "Acton / Ealing", "Hillingdon-wide"],
  "Birmingham": ["Birmingham"],
  "Manchester": ["Manchester"],
  "Leeds": ["Leeds"],
  "Liverpool": ["Liverpool"],
  "Hertfordshire": ["Hemel Hempstead", "Watford", "St Albans", "Stevenage", "Hatfield", "Hertford", "Welwyn Garden City"],
  "Buckinghamshire": ["Amersham", "Aylesbury", "Beaconsfield", "Bourne End", "Burnham", "Chesham", "Denham", "Flackwell Heath", "Gerrards Cross", "Great Missenden", "Hazlemere", "High Wycombe", "Iver", "Loudwater", "Maidenhead", "Marlow", "Princes Risborough", "Rickmansworth", "Slough", "Taplow", "Wendover", "Windsor", "Wooburn"],
  "Essex": ["Chelmsford", "Southend", "Colchester", "Basildon", "Brentwood", "Epping", "Harlow", "Braintree", "Maldon", "Thurrock", "Billericay", "Rayleigh", "Wickford", "Benfleet", "Grays", "Loughton", "Chigwell", "Romford"],
};

function getSearchScore(item, query) {
  const q = query.toLowerCase().trim();
  if (!q) return 1;
  
  let score = 0;
  const name = item.name.toLowerCase();
  const type = item.type.toLowerCase();
  const loc = item.location.toLowerCase();
  const desc = item.description.toLowerCase();
  const venue = item.venue.toLowerCase();
  
  // Exact name match — highest priority
  if (name.includes(q)) score += 100;
  // Type match
  if (type.includes(q)) score += 80;
  // Location match
  if (loc.includes(q)) score += 70;
  // Venue match
  if (venue.includes(q)) score += 60;
  // Description match
  if (desc.includes(q)) score += 40;
  
  // Keyword matching — check each keyword
  for (const [keyword, types] of Object.entries(searchKeywords)) {
    if (q.includes(keyword) || keyword.includes(q)) {
      if (types.includes(item.type)) score += 50;
      // Bonus if keyword appears in description too
      if (desc.includes(keyword)) score += 20;
    }
  }
  
  // Multi-word search — check each word
  const words = q.split(/\s+/);
  if (words.length > 1) {
    words.forEach(word => {
      if (word.length < 2) return;
      if (name.includes(word)) score += 30;
      if (type.includes(word)) score += 25;
      if (desc.includes(word)) score += 15;
      if (loc.includes(word)) score += 15;
    });
  }
  
  return score;
}

  const dayNames = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
  const dayNamesShort = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
  const todayName = dayNames[new Date().getDay()];
  const todayNameShort = dayNamesShort[new Date().getDay()];

  const filtered = useMemo(() => {
    let results = listings.filter(l => {
      if (showFavourites && !favourites.includes(l.id)) return false;
      if (cityFilter !== "All" && !cityGroups[cityFilter]?.some(a => l.location.includes(a))) return false;
      if (typeFilter !== "All Types" && l.type !== typeFilter) return false;
      if (areaFilter !== "All Areas" && !l.location.includes(areaFilter)) return false;
      if (freeOnly && !l.free) return false;
      if (dayFilter === "today" && !isOnToday(l)) return false;
      if (dayFilter !== "all" && dayFilter !== "today" && !isOnDay(l, parseInt(dayFilter))) return false;
      if (weatherMode === "rainy" && !l.indoor) return false;
      if (weatherMode === "sunny" && l.indoor) return false;
      if (napFilter === "morning" && l.timeSlot !== "morning" && l.timeSlot !== "all-day") return false;
      if (napFilter === "afternoon" && l.timeSlot !== "afternoon" && l.timeSlot !== "all-day") return false;
      if (search) {
        const score = getSearchScore(l, search);
        if (score === 0) return false;
      }
      return true;
    });
    if (search) {
      results.sort((a, b) => getSearchScore(b, search) - getSearchScore(a, search));
    } else if (sortBy === "nearest" && userLoc) {
      results.sort((a, b) => getDistanceMiles(userLoc.lat, userLoc.lng, a.lat, a.lng) - getDistanceMiles(userLoc.lat, userLoc.lng, b.lat, b.lng));
    } else if (sortBy === "price-low") {
      results.sort((a, b) => {
        const pa = a.free ? 0 : parseFloat((a.price.match(/[\d.]+/) || [999])[0]);
        const pb = b.free ? 0 : parseFloat((b.price.match(/[\d.]+/) || [999])[0]);
        return pa - pb;
      });
    } else if (sortBy === "price-high") {
      results.sort((a, b) => {
        const pa = a.free ? 0 : parseFloat((a.price.match(/[\d.]+/) || [0])[0]);
        const pb = b.free ? 0 : parseFloat((b.price.match(/[\d.]+/) || [0])[0]);
        return pb - pa;
      });
    } else if (sortBy === "free-first") {
      results.sort((a, b) => (b.free ? 1 : 0) - (a.free ? 1 : 0));
    } else if (sortBy === "indoor") {
      results.sort((a, b) => (b.indoor ? 1 : 0) - (a.indoor ? 1 : 0));
    } else if (sortBy === "outdoor") {
      results.sort((a, b) => (a.indoor ? 1 : 0) - (b.indoor ? 1 : 0));
    } else {
      // "mixed" — ensure variety of types on each page
      const types = [...new Set(results.map(r => r.type))];
      const buckets = {};
      types.forEach(t => { buckets[t] = results.filter(r => r.type === t); });
      const mixed = [];
      let safety = results.length + 10;
      while (mixed.length < results.length && safety-- > 0) {
        for (const t of types) {
          if (buckets[t].length > 0) mixed.push(buckets[t].shift());
        }
      }
      results = mixed;
    }
    return results;
  }, [listings, showFavourites, favourites, cityFilter, typeFilter, areaFilter, freeOnly, search, userLoc, dayFilter, weatherMode, napFilter, sortBy]);

  const areaPreviewCounts = useMemo(() => {
    const counts = {};
    ["Ealing", "Ruislip", "Eastcote", "Uxbridge"].forEach(area => {
      counts[area] = listings.filter(l => {
        if (!l.location.includes(area)) return false;
        if (showFavourites && !favourites.includes(l.id)) return false;
        if (cityFilter !== "All" && !cityGroups[cityFilter]?.some(a => l.location.includes(a))) return false;
        if (typeFilter !== "All Types" && l.type !== typeFilter) return false;
        if (freeOnly && !l.free) return false;
        if (dayFilter === "today" && !isOnToday(l)) return false;
        if (dayFilter !== "all" && dayFilter !== "today" && !isOnDay(l, parseInt(dayFilter))) return false;
        if (weatherMode === "rainy" && !l.indoor) return false;
        if (weatherMode === "sunny" && l.indoor) return false;
        if (napFilter === "morning" && l.timeSlot !== "morning" && l.timeSlot !== "all-day") return false;
        if (napFilter === "afternoon" && l.timeSlot !== "afternoon" && l.timeSlot !== "all-day") return false;
        if (search && getSearchScore(l, search) === 0) return false;
        return true;
      }).length;
    });
    return counts;
  }, [listings, showFavourites, favourites, cityFilter, typeFilter, freeOnly, search, dayFilter, weatherMode, napFilter]);

  const sortedAreas = useMemo(() => {
    const allAreas = ["All Areas", "Chiswick", "Ealing", "Acton", "Hammersmith", "Shepherd's Bush", "Kew", "Ruislip", "Uxbridge", "Eastcote", "Hillingdon", "Ickenham", "Northwood", "Northolt", "South Ruislip", "Camden", "Islington", "Finchley", "Barnet", "Highgate", "Hampstead", "Brixton", "Clapham", "Dulwich", "Greenwich", "Peckham", "Wimbledon", "Crystal Palace", "Forest Hill", "Battersea", "Croydon", "Lewisham", "Stratford", "Hackney", "Canary Wharf", "Romford", "Bethnal Green", "Walthamstow", "Lea Bridge", "Silvertown", "Kensington", "Westminster", "South Kensington", "Southwark", "Covent Garden", "London Bridge", "Regent's Park", "Pinner", "Harrow", "Hayes", "Southall", "Hounslow", "Feltham", "Greenford", "Stanmore", "Edgware", "Wembley", "Hanwell", "Brentford", "Twickenham", "Richmond", "Isleworth", "Hemel Hempstead", "Watford", "St Albans", "Stevenage", "Hatfield", "Hertford", "Welwyn Garden City", "High Wycombe", "Amersham", "Aylesbury", "Marlow", "Beaconsfield", "Chesham", "Princes Risborough", "Slough", "Iver", "Gerrards Cross", "Burnham", "Taplow", "Wendover", "Great Missenden", "Maidenhead", "Windsor", "Denham", "Rickmansworth", "Chelmsford", "Southend", "Colchester", "Basildon", "Brentwood", "Epping", "Harlow", "Braintree", "Maldon", "Thurrock", "Birmingham", "Manchester", "Leeds", "Liverpool"];
    if (!userLoc) return allAreas;
    const areaAvgDist = {};
    allAreas.forEach(area => {
      if (area === "All Areas") { areaAvgDist[area] = -1; return; }
      const al = listings.filter(l => l.location.includes(area));
      if (al.length === 0) { areaAvgDist[area] = 999; return; }
      areaAvgDist[area] = al.reduce((s, l) => s + getDistanceMiles(userLoc.lat, userLoc.lng, l.lat, l.lng), 0) / al.length;
    });
    return allAreas.sort((a, b) => areaAvgDist[a] - areaAvgDist[b]);
  }, [userLoc]);

  const todayCount = useMemo(() => listings.filter(l => isOnToday(l)).length, [listings]);

  if (showCalendar) {
    const today = new Date();
    const [calMonth, setCalMonth] = useState(today.getMonth());
    const [calYear, setCalYear] = useState(today.getFullYear());
    const [selectedDate, setSelectedDate] = useState(today.toISOString().split("T")[0]);

    const monthNames = ["January","February","March","April","May","June","July","August","September","October","November","December"];
    const dayLabels = ["Mo","Tu","We","Th","Fr","Sa","Su"];
    const todayKey = today.toISOString().split("T")[0];

    // Build calendar grid
    const firstDay = new Date(calYear, calMonth, 1);
    const lastDay = new Date(calYear, calMonth + 1, 0);
    let startDow = firstDay.getDay(); // 0=Sun
    startDow = startDow === 0 ? 6 : startDow - 1; // convert to 0=Mon
    const daysInMonth = lastDay.getDate();
    const cells = [];
    for (let i = 0; i < startDow; i++) cells.push(null);
    for (let d = 1; d <= daysInMonth; d++) cells.push(d);

    const prevMonth = () => { if (calMonth === 0) { setCalMonth(11); setCalYear(calYear - 1); } else setCalMonth(calMonth - 1); };
    const nextMonth = () => { if (calMonth === 11) { setCalMonth(0); setCalYear(calYear + 1); } else setCalMonth(calMonth + 1); };

    const selectedActivities = (calendarPlan[selectedDate] || []).map(id => listings.find(l => l.id === id)).filter(Boolean);

    return (
      <div style={{ maxWidth: 500, margin: "0 auto", background: "#FFF9F5", minHeight: "100vh", fontFamily: "system-ui, -apple-system, sans-serif", color: "#2D3142", overflowX: "hidden" }}>
        <div style={{ padding: "12px 20px 6px", position: "sticky", top: 0, zIndex: 100, background: "#FFF9F5", borderBottom: "1px solid #F0EBE6" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <div onClick={closeCalendar} style={{ display: "flex", alignItems: "center", gap: 6, cursor: "pointer" }}>
              <div style={{ width: 60, height: 60, overflow: "hidden", flexShrink: 0, borderRadius: 14, border: "2px solid #C4B8D4" }}><BrandBear size={60} /></div>
              <div>
                <div style={{ fontSize: 22, fontWeight: 800, color: "#C4B8D4", letterSpacing: -0.3 }}>LITTLE<span style={{ color: "#E8917A" }}>locals</span></div>
              </div>
            </div>
            <div onClick={closeCalendar} style={{ padding: "6px 12px", background: "white", borderRadius: 10, border: "1px solid #E0DBD5", cursor: "pointer", fontSize: 12, fontWeight: 600, color: "#5C4B6B" }}>← Back</div>
          </div>
        </div>

        <div style={{ padding: "16px 20px 8px" }}>
          <div style={{ fontSize: 18, fontWeight: 800, color: "#5C4B6B", marginBottom: 4 }}>📅 My Plans</div>
          <div style={{ fontSize: 12, color: "#A89BB0", marginBottom: 12 }}>Tap a date to view or add activities</div>

          {/* Month nav */}
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
            <div onClick={prevMonth} style={{ padding: "6px 12px", background: "white", borderRadius: 8, border: "1px solid #E0DBD5", cursor: "pointer", fontSize: 14, fontWeight: 700 }}>‹</div>
            <div style={{ fontSize: 15, fontWeight: 800, color: "#5C4B6B" }}>{monthNames[calMonth]} {calYear}</div>
            <div onClick={nextMonth} style={{ padding: "6px 12px", background: "white", borderRadius: 8, border: "1px solid #E0DBD5", cursor: "pointer", fontSize: 14, fontWeight: 700 }}>›</div>
          </div>

          {/* Day labels */}
          <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 2, marginBottom: 4 }}>
            {dayLabels.map(d => <div key={d} style={{ textAlign: "center", fontSize: 10, fontWeight: 700, color: "#A89BB0", padding: 4 }}>{d}</div>)}
          </div>

          {/* Calendar grid */}
          <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 2, marginBottom: 12 }}>
            {cells.map((d, i) => {
              if (d === null) return <div key={`e${i}`} />;
              const dateKey = `${calYear}-${String(calMonth + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
              const hasPlans = (calendarPlan[dateKey] || []).length > 0;
              const isToday = dateKey === todayKey;
              const isSelected = dateKey === selectedDate;
              const isPast = dateKey < todayKey;
              return (
                <div key={dateKey} onClick={() => setSelectedDate(dateKey)} style={{
                  textAlign: "center", padding: "8px 0", borderRadius: 10, cursor: "pointer", position: "relative",
                  background: isSelected ? "linear-gradient(135deg, #E8917A, #F0B89A)" : isToday ? "#FFF0EB" : "white",
                  color: isSelected ? "white" : isPast ? "#C4B8CB" : "#5C4B6B",
                  border: isToday && !isSelected ? "2px solid #E8917A" : "1px solid #F0EBE6",
                  fontWeight: isToday || isSelected ? 800 : 600, fontSize: 13
                }}>
                  {d}
                  {hasPlans && <div style={{ position: "absolute", bottom: 3, left: "50%", transform: "translateX(-50%)", width: 5, height: 5, borderRadius: "50%", background: isSelected ? "white" : "#E8917A" }} />}
                </div>
              );
            })}
          </div>
        </div>

        {/* Selected date detail */}
        <div style={{ padding: "0 20px 12px" }}>
          <div style={{ fontSize: 14, fontWeight: 800, color: "#5C4B6B", marginBottom: 8 }}>
            {selectedDate === todayKey ? "📍 Today" : new Date(selectedDate + "T12:00:00").toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long" })}
            <span style={{ fontSize: 12, fontWeight: 600, color: "#A89BB0", marginLeft: 8 }}>{selectedActivities.length} {selectedActivities.length === 1 ? "activity" : "activities"}</span>
          </div>

          {selectedActivities.length === 0 ? (
            <div style={{ padding: "20px", textAlign: "center", background: "white", borderRadius: 14, border: "1px solid #F0EBE6" }}>
              <div style={{ fontSize: 28, marginBottom: 6 }}>📅</div>
              <div style={{ fontSize: 12, color: "#A89BB0" }}>Nothing planned yet</div>
              <div onClick={closeCalendar} style={{ display: "inline-block", marginTop: 8, padding: "6px 16px", background: "linear-gradient(135deg, #E8917A, #F0B89A)", color: "white", borderRadius: 10, fontSize: 11, fontWeight: 700, cursor: "pointer" }}>Browse Activities</div>
            </div>
          ) : (
            selectedActivities.map(item => (
              <div key={item.id} style={{ padding: "10px 14px", background: "white", borderRadius: 14, border: "1px solid #F0EBE6", marginBottom: 6, display: "flex", alignItems: "center", gap: 10 }}>
                <div style={{ fontSize: 24 }}>{item.emoji}</div>
                <div style={{ flex: 1 }} onClick={() => { closeCalendar(); setTimeout(() => openDetail(item), 50); }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: "#2D3142", cursor: "pointer" }}>{item.name}</div>
                  <div style={{ fontSize: 11, color: "#A89BB0" }}>{item.time || item.day} · 📍 {item.location}</div>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                  <span style={{ fontSize: 11, fontWeight: 700, color: item.free ? "#2EC4B6" : "#E8917A" }}>{item.price}</span>
                  <div onClick={() => removeFromCalendar(item.id, selectedDate)} style={{ width: 26, height: 26, borderRadius: "50%", background: "#FFF0EB", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", fontSize: 12 }}>✕</div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Activity Passport */}
        <div style={{ padding: "0 20px 16px" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
            <div style={{ fontSize: 16, fontWeight: 800, color: "#5C4B6B" }}>🏆 Activity Passport</div>
            <div style={{ fontSize: 12, fontWeight: 700, color: "#2EC4B6" }}>{passport.length} visited</div>
          </div>

          {passport.length === 0 ? (
            <div style={{ padding: "20px", textAlign: "center", background: "white", borderRadius: 14, border: "1px solid #F0EBE6" }}>
              <div style={{ fontSize: 28, marginBottom: 6 }}>🏆</div>
              <div style={{ fontSize: 13, fontWeight: 700, color: "#5C4B6B", marginBottom: 4 }}>Start collecting!</div>
              <div style={{ fontSize: 11, color: "#A89BB0" }}>Tap "Been here?" on activities your family has tried</div>
            </div>
          ) : (
            <>
              {/* Progress by type */}
              {(() => {
                const visitedItems = passport.map(id => listings.find(l => l.id === id)).filter(Boolean);
                const typeCounts = {};
                visitedItems.forEach(v => { typeCounts[v.type] = (typeCounts[v.type] || 0) + 1; });
                const typeTotal = {};
                listings.forEach(l => { typeTotal[l.type] = (typeTotal[l.type] || 0) + 1; });
                return (
                  <div style={{ marginBottom: 10 }}>
                    {Object.entries(typeCounts).sort((a, b) => b[1] - a[1]).map(([type, count]) => (
                      <div key={type} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
                        <div style={{ fontSize: 11, fontWeight: 700, color: "#5C4B6B", width: 90, flexShrink: 0 }}>{type}</div>
                        <div style={{ flex: 1, height: 8, background: "#F0EBE6", borderRadius: 4, overflow: "hidden" }}>
                          <div style={{ width: `${Math.min(100, (count / (typeTotal[type] || 1)) * 100)}%`, height: "100%", background: "linear-gradient(90deg, #2EC4B6, #7BDDD5)", borderRadius: 4 }} />
                        </div>
                        <div style={{ fontSize: 10, fontWeight: 700, color: "#2EC4B6", width: 36, textAlign: "right" }}>{count}/{typeTotal[type] || 0}</div>
                      </div>
                    ))}
                  </div>
                );
              })()}

              {/* Sticker collection */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 6 }}>
                {passport.map(id => {
                  const item = listings.find(l => l.id === id);
                  if (!item) return null;
                  return (
                    <div key={id} onClick={() => { closeCalendar(); setTimeout(() => openDetail(item), 50); }} style={{ textAlign: "center", padding: "8px 4px", background: "white", borderRadius: 12, border: "1px solid #F0EBE6", cursor: "pointer" }}>
                      <div style={{ fontSize: 24, marginBottom: 2 }}>{item.emoji}</div>
                      <div style={{ fontSize: 8, fontWeight: 700, color: "#5C4B6B", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{item.name}</div>
                      <div style={{ fontSize: 7, color: "#2EC4B6", fontWeight: 600 }}>✓ Visited</div>
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </div>

        <div style={{ padding: "8px 20px 24px", textAlign: "center" }}>
          <div onClick={closeCalendar} style={{ display: "inline-block", padding: "10px 24px", background: "linear-gradient(135deg, #E8917A, #F0B89A)", color: "white", borderRadius: 12, fontSize: 13, fontWeight: 700, cursor: "pointer" }}>Browse Activities to Add More</div>
        </div>
      </div>
    );
  }

  if (selected) {
    return (
      <div style={{ maxWidth: 500, margin: "0 auto", background: "#FFF9F5", minHeight: "100vh", fontFamily: "system-ui, -apple-system, sans-serif", color: "#2D3142", overflowX: "hidden" }}>
        <DetailView item={selected} onBack={closeDetail} userLoc={userLoc} reviews={reviews} onAddReview={addReview} isFav={favourites.includes(selected.id)} onToggleFav={toggleFavourite} onAddToCalendar={addToCalendar} calendarPlan={calendarPlan} isVisited={passport.includes(selected.id)} onToggleVisited={togglePassport} />
      </div>
    );
  }

  const Chip = ({ active, onClick, children, color = "#2D3142", activeBg = "#FF6B6B" }) => (
    <div onClick={() => { if (navigator.vibrate) navigator.vibrate(8); onClick(); }} style={{ flexShrink: 0, padding: "6px 12px", borderRadius: 16, fontSize: 11, fontWeight: 600, background: active ? activeBg : "white", color: active ? "white" : color, border: `1px solid ${active ? activeBg : "#E0DBD5"}`, cursor: "pointer", whiteSpace: "nowrap" }}>{children}</div>
  );

  return (
    <div style={{ maxWidth: 500, margin: "0 auto", background: "#FFF9F5", minHeight: "100vh", fontFamily: "system-ui, -apple-system, sans-serif", color: "#2D3142", overflowX: "hidden" }}>
      {/* HEADER */}
      <div style={{ padding: showScrollTop ? "8px 20px 4px" : "12px 20px 6px", position: "sticky", top: 0, zIndex: 100, background: "#FFF9F5", borderBottom: "1px solid #F0EBE6", transition: "padding 0.2s" }}>
        {!showScrollTop ? (
          <>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <div onClick={() => { window.scrollTo({ top: 0, behavior: "smooth" }); setShowSuggest(false); setSelected(null); }} style={{ display: "flex", alignItems: "center", gap: 6, cursor: "pointer" }}>
                <div style={{ width: 60, height: 60, overflow: "hidden", flexShrink: 0, borderRadius: 14, border: "2px solid #C4B8D4" }}><BrandBear size={60} /></div>
                <div>
                  <div style={{ fontSize: 16, fontWeight: 800, color: "#5C4B6B", letterSpacing: -0.3, lineHeight: 1.3 }}>{"Find something lovely to do with the kids" + (areaFilter !== "All Areas" ? " in " + areaFilter : "")}</div>
                </div>
              </div>
              <div onClick={() => { try { navigator.clipboard.writeText(window.location.href).then(() => { setShareCopied(true); setTimeout(() => setShareCopied(false), 2000); }); } catch(e) { setShareCopied(true); setTimeout(() => setShareCopied(false), 2000); } }} style={{ width: 34, height: 34, borderRadius: 10, background: "rgba(255,255,255,0.12)", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", flexShrink: 0, transition: "all 0.2s" }}><span style={{ fontSize: 15 }}>{shareCopied ? "✓" : "🔗"}</span></div>
            </div>
            <div style={{ fontSize: 11, color: "#A89BB0", marginTop: 4, marginLeft: 66, lineHeight: 1.4 }}>Trusted by local {areaFilter !== "All Areas" ? areaFilter : "Ealing"} parents</div>
          </>
        ) : (
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <div onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} style={{ width: 32, height: 32, overflow: "hidden", flexShrink: 0, borderRadius: 8, border: "1.5px solid #C4B8D4", cursor: "pointer" }}><BrandBear size={32} /></div>
            <div style={{ flex: 1, minWidth: 0, background: "white", borderRadius: 10, padding: "6px 12px", display: "flex", alignItems: "center", gap: 6, border: "1px solid #F0E8E0" }}>
              <span style={{ fontSize: 12 }}>🔍</span>
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search activities..." style={{ border: "none", outline: "none", fontSize: 12, flex: 1, minWidth: 0, background: "transparent", fontFamily: "inherit" }} />
            </div>
            <select value={cityFilter} onChange={e => { setCityFilter(e.target.value); setAreaFilter("All Areas"); setPage(1); }} style={{ fontSize: 10, padding: "4px 4px", borderRadius: 6, border: "1px solid #E0DBD5", background: "white", color: "#5C4B6B", fontWeight: 600, fontFamily: "inherit", maxWidth: 80 }}>
              <option value="All">🇬🇧 All</option>
              <option value="London">London</option>
              <option value="Hertfordshire">Herts</option>
              <option value="Buckinghamshire">Bucks</option>
              <option value="Essex">Essex</option>
              <option value="Birmingham">Bham</option>
              <option value="Manchester">Manc</option>
              <option value="Leeds">Leeds</option>
              <option value="Liverpool">L'pool</option>
            </select>
          </div>
        )}
      </div>

      {/* Pull to refresh indicator */}
      {pullRefreshing && (
        <div style={{ textAlign: "center", padding: "8px 0" }}>
          <div style={{ display: "inline-block", width: 20, height: 20, border: "2px solid #E0DBD5", borderTopColor: "#E8917A", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
          <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        </div>
      )}

      {/* Loading spinner on first load */}
      {isLoading && (
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "60px 20px", gap: 12 }}>
          <div style={{ width: 36, height: 36, border: "3px solid #F0EBE6", borderTopColor: "#E8917A", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
          <div style={{ fontSize: 13, color: "#A89BB0", fontWeight: 600 }}>Loading activities...</div>
          <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        </div>
      )}

      {!isLoading && <>

      {/* Suggest Submitted Confirmation */}
      {suggestSubmitted && (
        <div style={{ margin: "6px 20px 8px", padding: "12px 16px", background: "#F0F7F0", borderRadius: 14, textAlign: "center" }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: "#7BAF7B" }}>🎉 Activity submitted!</div>
          <div style={{ fontSize: 11, color: "#A89BB0", marginTop: 2 }}>We'll review it and add it to LITTLElocals soon</div>
        </div>
      )}

      {/* Suggest Activity Form — inline when open */}
      {showSuggest && (
        <div style={{ margin: "6px 20px 10px" }}>
          <div style={{ background: "white", borderRadius: 16, padding: 18, border: "1px solid #F0E8E0", boxShadow: "0 4px 16px rgba(92,75,107,0.06)" }}>
            <div style={{ fontSize: 16, fontWeight: 800, marginBottom: 2, color: "#5C4B6B" }}>✨ Suggest an Activity</div>
            <div style={{ fontSize: 11, color: "#A89BB0", marginBottom: 14 }}>Mums, dads & providers welcome — we'll review and add it!</div>
            <div style={{ fontSize: 11, fontWeight: 600, color: "#6B7394", marginBottom: 4 }}>Activity Name *</div>
            <input value={suggestForm.name} onChange={e => setSuggestForm(p => ({...p, name: e.target.value}))} placeholder="e.g. Tiny Tots Music Class" style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1px solid #E0DBD5", fontSize: 13, fontFamily: "inherit", marginBottom: 10, boxSizing: "border-box", outline: "none" }} />
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginBottom: 10 }}>
              <div>
                <div style={{ fontSize: 11, fontWeight: 600, color: "#6B7394", marginBottom: 4 }}>Type *</div>
                <select value={suggestForm.type} onChange={e => setSuggestForm(p => ({...p, type: e.target.value}))} style={{ width: "100%", padding: "10px 8px", borderRadius: 10, border: "1px solid #E0DBD5", fontSize: 12, fontFamily: "inherit", background: "white", boxSizing: "border-box" }}>
                  {Object.keys(typeColors).map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
              <div>
                <div style={{ fontSize: 11, fontWeight: 600, color: "#6B7394", marginBottom: 4 }}>City *</div>
                <select value={suggestForm.city} onChange={e => setSuggestForm(p => ({...p, city: e.target.value, location: ""}))} style={{ width: "100%", padding: "10px 8px", borderRadius: 10, border: "1px solid #E0DBD5", fontSize: 12, fontFamily: "inherit", background: "white", boxSizing: "border-box" }}>
                  {Object.keys(cityGroups).map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <div style={{ position: "relative" }}>
                <div style={{ fontSize: 11, fontWeight: 600, color: "#6B7394", marginBottom: 4 }}>Area *</div>
                <input value={suggestForm.location} onChange={e => setSuggestForm(p => ({...p, location: e.target.value}))} placeholder="Type area name..." style={{ width: "100%", padding: "10px 8px", borderRadius: 10, border: "1px solid #E0DBD5", fontSize: 12, fontFamily: "inherit", background: "white", boxSizing: "border-box", outline: "none" }} onFocus={e => e.target.setAttribute("data-open","1")} onBlur={e => setTimeout(() => e.target.removeAttribute("data-open"), 200)} />
                {suggestForm.location && suggestForm.location.length > 0 && (() => {
                  const areas = (cityGroups[suggestForm.city] || []).filter(a => !a.includes("/") && a !== "Hillingdon-wide" && a.toLowerCase().includes(suggestForm.location.toLowerCase()));
                  const exactMatch = (cityGroups[suggestForm.city] || []).some(a => a.toLowerCase() === suggestForm.location.toLowerCase());
                  if (exactMatch || areas.length === 0) return null;
                  return <div style={{ position: "absolute", top: "100%", left: 0, right: 0, background: "white", border: "1px solid #E0DBD5", borderRadius: 10, marginTop: 2, maxHeight: 150, overflowY: "auto", zIndex: 10, boxShadow: "0 4px 12px rgba(0,0,0,0.1)" }}>
                    {areas.slice(0, 8).map(a => <div key={a} onMouseDown={() => setSuggestForm(p => ({...p, location: a}))} style={{ padding: "8px 10px", fontSize: 12, cursor: "pointer", borderBottom: "1px solid #F0EBE6" }}>{a}</div>)}
                  </div>;
                })()}
              </div>
            </div>
            <div style={{ fontSize: 11, fontWeight: 600, color: "#6B7394", marginBottom: 4 }}>Venue / Address *</div>
            <input value={suggestForm.venue} onChange={e => setSuggestForm(p => ({...p, venue: e.target.value}))} placeholder="e.g. St Mary's Church Hall, High St, HA4 7AY" style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1px solid #E0DBD5", fontSize: 13, fontFamily: "inherit", marginBottom: 10, boxSizing: "border-box", outline: "none" }} />
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 10 }}>
              <div><div style={{ fontSize: 11, fontWeight: 600, color: "#6B7394", marginBottom: 4 }}>Ages</div><input value={suggestForm.ages} onChange={e => setSuggestForm(p => ({...p, ages: e.target.value}))} placeholder="0–5yrs" style={{ width: "100%", padding: "10px 8px", borderRadius: 10, border: "1px solid #E0DBD5", fontSize: 12, fontFamily: "inherit", boxSizing: "border-box", outline: "none" }} /></div>
              <div><div style={{ fontSize: 11, fontWeight: 600, color: "#6B7394", marginBottom: 4 }}>Day(s)</div><input value={suggestForm.day} onChange={e => setSuggestForm(p => ({...p, day: e.target.value}))} placeholder="Mondays" style={{ width: "100%", padding: "10px 8px", borderRadius: 10, border: "1px solid #E0DBD5", fontSize: 12, fontFamily: "inherit", boxSizing: "border-box", outline: "none" }} /></div>
              <div><div style={{ fontSize: 11, fontWeight: 600, color: "#6B7394", marginBottom: 4 }}>Time</div><input value={suggestForm.time} onChange={e => setSuggestForm(p => ({...p, time: e.target.value}))} placeholder="10:00 AM" style={{ width: "100%", padding: "10px 8px", borderRadius: 10, border: "1px solid #E0DBD5", fontSize: 12, fontFamily: "inherit", boxSizing: "border-box", outline: "none" }} /></div>
              <div><div style={{ fontSize: 11, fontWeight: 600, color: "#6B7394", marginBottom: 4 }}>Price</div><input value={suggestForm.price} onChange={e => setSuggestForm(p => ({...p, price: e.target.value}))} placeholder="£8" style={{ width: "100%", padding: "10px 8px", borderRadius: 10, border: "1px solid #E0DBD5", fontSize: 12, fontFamily: "inherit", boxSizing: "border-box", outline: "none" }} /></div>
            </div>
            <div style={{ fontSize: 11, fontWeight: 600, color: "#6B7394", marginBottom: 4 }}>Description</div>
            <textarea value={suggestForm.description} onChange={e => setSuggestForm(p => ({...p, description: e.target.value}))} placeholder="Tell us what makes this activity great..." rows={3} style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1px solid #E0DBD5", fontSize: 13, fontFamily: "inherit", marginBottom: 10, boxSizing: "border-box", resize: "vertical", outline: "none" }} />
            <div style={{ borderTop: "1px solid #F0EBE6", paddingTop: 12, marginBottom: 10 }}>
              <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 8 }}>Your Details</div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
                <input value={suggestForm.submitterName} onChange={e => setSuggestForm(p => ({...p, submitterName: e.target.value}))} placeholder="Your name *" style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1px solid #E0DBD5", fontSize: 12, fontFamily: "inherit", boxSizing: "border-box", outline: "none" }} />
                <input value={suggestForm.submitterEmail} onChange={e => setSuggestForm(p => ({...p, submitterEmail: e.target.value}))} placeholder="Email (optional)" style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1px solid #E0DBD5", fontSize: 12, fontFamily: "inherit", boxSizing: "border-box", outline: "none" }} />
              </div>
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <button onClick={closeSuggest} style={{ flex: 1, padding: 12, borderRadius: 10, border: "1px solid #E0DBD5", background: "white", fontSize: 12, fontWeight: 600, cursor: "pointer", fontFamily: "inherit", color: "#6B7394" }}>Cancel</button>
              <button onClick={submitSuggestion} disabled={!suggestForm.name.trim() || !suggestForm.venue.trim() || !suggestForm.submitterName.trim() || !suggestForm.location} style={{ flex: 1.5, padding: 12, borderRadius: 10, border: "none", background: suggestForm.name.trim() && suggestForm.venue.trim() && suggestForm.submitterName.trim() && suggestForm.location ? "linear-gradient(135deg, #E8917A, #F0B89A)" : "#E0DBD5", color: "white", fontSize: 13, fontWeight: 700, cursor: suggestForm.name.trim() && suggestForm.venue.trim() && suggestForm.submitterName.trim() && suggestForm.location ? "pointer" : "default", fontFamily: "inherit" }}>Submit for Review 🧡</button>
            </div>
          </div>
        </div>
      )}

      {/* Stats bar — 3 dropdowns on one line, count + share below */}
      <div style={{ padding: "6px 20px 2px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
          <select value={dayFilter} onChange={e => { setDayFilter(e.target.value); setPage(1); }} style={{ fontSize: 10, padding: "3px 3px", borderRadius: 8, border: "1px solid #EDE8E3", background: "white", color: "#6B7394", fontWeight: 600, fontFamily: "inherit", flex: 3, minWidth: 0 }}>
            <option value="today">📅 Today ({todayNameShort})</option>
            <option value="1">Mon</option>
            <option value="2">Tue</option>
            <option value="3">Wed</option>
            <option value="4">Thu</option>
            <option value="5">Fri</option>
            <option value="6">Sat</option>
            <option value="0">Sun</option>
            <option value="all">All Days</option>
          </select>
          <select value={cityFilter} onChange={e => { setCityFilter(e.target.value); setAreaFilter("All Areas"); setPage(1); }} style={{ fontSize: 10, padding: "3px 3px", borderRadius: 8, border: "1px solid #EDE8E3", background: "white", color: "#6B7394", fontWeight: 600, fontFamily: "inherit", flex: 2, minWidth: 0 }}>
            <option value="All">🇬🇧 UK</option>
            <option value="London">London</option>
            <option value="Hertfordshire">Herts</option>
            <option value="Buckinghamshire">Bucks</option>
            <option value="Essex">Essex</option>
            <option value="Birmingham">Bham</option>
            <option value="Manchester">Manc</option>
            <option value="Leeds">Leeds</option>
            <option value="Liverpool">L'pool</option>
          </select>
          <select value={sortBy} onChange={e => { setSortBy(e.target.value); if (e.target.value === "nearest") { setAreaFilter("All Areas"); } setPage(1); }} style={{ fontSize: 10, padding: "3px 3px", borderRadius: 8, border: "1px solid #EDE8E3", background: "white", color: "#6B7394", fontWeight: 600, fontFamily: "inherit", flex: 2, minWidth: 0 }}>
            <option value="mixed">🎲 Mixed</option>
            <option value="nearest">📍 Near</option>
            <option value="price-low">💰 Low £</option>
            <option value="price-high">💰 High £</option>
            <option value="free-first">🎉 Free</option>
            <option value="indoor">🏠 In</option>
            <option value="outdoor">🌳 Out</option>
          </select>
        </div>
        <div style={{ marginTop: 4 }}>
          <span style={{ fontSize: 11, color: "#A89BB0" }}>{filtered.length} activities handpicked for {areaFilter !== "All Areas" ? areaFilter : "Ealing"} families</span>
        </div>
      </div>

      {/* Location banner — compact */}
      {locStatus === "idle" && (
        <div onClick={requestLocation} style={{ margin: "2px 20px 6px", padding: "8px 14px", background: "#FFF7F0", borderRadius: 12, display: "flex", alignItems: "center", gap: 8, cursor: "pointer", border: "1px dashed #F0D5C0" }}>
          <span style={{ fontSize: 14 }}>📍</span>
          <span style={{ fontSize: 11, fontWeight: 600, color: "#5C4B6B", flex: 1 }}>Sort by nearest to you</span>
          <span style={{ fontSize: 10, fontWeight: 700, color: "#E8917A" }}>Enable</span>
        </div>
      )}
      {locStatus === "requesting" && <div style={{ margin: "2px 20px 6px", padding: "8px 14px", background: "#FFF7F0", borderRadius: 12, fontSize: 11, textAlign: "center", color: "#C4956A" }}>📍 Getting your location...</div>}
      {locStatus === "granted" && (
        <div style={{ margin: "2px 20px 6px", padding: "6px 14px", background: "#F0F7F0", borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <span style={{ fontSize: 11, fontWeight: 600, color: "#7BAF7B" }}>📍 Nearest first</span>
          <span onClick={() => { setUserLoc(null); setLocStatus("idle"); setSortBy("mixed"); }} style={{ fontSize: 10, color: "#A89BB0", cursor: "pointer" }}>✕</span>
        </div>
      )}
      {locStatus === "denied" && (
        <div style={{ margin: "2px 20px 6px", padding: "6px 14px", background: "#FFF7F0", borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <span style={{ fontSize: 11, color: "#C4956A" }}>📍 Location unavailable</span>
          <span onClick={() => setLocStatus("idle")} style={{ fontSize: 10, color: "#A89BB0", cursor: "pointer" }}>Retry</span>
        </div>
      )}

      {/* Search */}
      <div style={{ margin: "4px 20px 8px", display: "flex", gap: 8, alignItems: "center" }}>
        <div style={{ flex: 1, background: "white", borderRadius: 14, padding: "8px 14px", display: "flex", alignItems: "center", gap: 8, border: "1px solid #F0E8E0" }}>
          <span style={{ fontSize: 14 }}>🔍</span>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search activities..." style={{ border: "none", outline: "none", fontSize: 13, flex: 1, background: "transparent", fontFamily: "inherit", minWidth: 0 }} />
        </div>
        <div onClick={() => { const newVal = !mapView; setMapView(newVal); if (newVal && locStatus === "idle") requestLocation(); if (newVal) setAreaFilter("All Areas"); }} style={{ padding: "8px 12px", background: mapView ? "linear-gradient(135deg, #E8917A, #F0B89A)" : "white", borderRadius: 14, border: mapView ? "none" : "1px solid #F0E8E0", cursor: "pointer", display: "flex", alignItems: "center", gap: 4, flexShrink: 0 }}>
          <span style={{ fontSize: 14 }}>{mapView ? "📋" : "🗺️"}</span>
          <span style={{ fontSize: 10, fontWeight: 700, color: mapView ? "white" : "#5C4B6B" }}>{mapView ? "List" : "Map"}</span>
        </div>
      </div>

      {/* Area selector chips — sticky below header */}
      <div style={{ position: "sticky", top: showScrollTop ? 44 : 0, zIndex: 99, background: "#FFF9F5", borderBottom: showScrollTop ? "1px solid #F0E8E0" : "none", boxShadow: showScrollTop ? "0 6px 14px rgba(0,0,0,0.06)" : "none", transition: "box-shadow 180ms ease, border-bottom 180ms ease" }}>
        <div style={{ position: "relative" }}>
          <div style={{ display: "flex", gap: 8, overflowX: "auto", padding: "8px 20px", WebkitOverflowScrolling: "touch", maxWidth: "100vw" }}>
            <Chip active={areaFilter === "All Areas"} onClick={() => { setAreaFilter("All Areas"); setPage(1); }} activeBg="#5C4B6B">All Areas <span style={{ opacity: 0.6, fontWeight: 500 }}>({Object.values(areaPreviewCounts).reduce((s, c) => s + c, 0)})</span></Chip>
            {["Ealing", "Ruislip", "Eastcote", "Uxbridge"].map(area => {
              const count = areaPreviewCounts[area];
              const isEmpty = count === 0 && areaFilter !== area;
              return <Chip key={area} active={areaFilter === area} onClick={isEmpty ? () => {} : () => { setAreaFilter(areaFilter === area ? "All Areas" : area); setPage(1); }} activeBg="#5C4B6B" color={isEmpty ? "#D4CADE" : "#2D3142"}>{area} <span style={{ opacity: isEmpty ? 0.4 : 0.6, fontWeight: 500 }}>({count})</span></Chip>;
            })}
          </div>
          {showScrollTop && (<>
            <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: 24, background: "linear-gradient(to right, #FFF9F5, rgba(255,249,245,0))", pointerEvents: "none" }} />
            <div style={{ position: "absolute", right: 0, top: 0, bottom: 0, width: 24, background: "linear-gradient(to left, #FFF9F5, rgba(255,249,245,0))", pointerEvents: "none" }} />
          </>)}
        </div>
        {showScrollTop && (() => {
          const parts = [];
          if (areaFilter && areaFilter !== "All Areas") parts.push(areaFilter);
          if (weatherMode === "rainy") parts.push("Indoor");
          if (weatherMode === "sunny") parts.push("Outdoor");
          if (freeOnly) parts.push("Free");
          if (dayFilter && dayFilter !== "today") parts.push(dayFilter === "all" ? "Any day" : ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"][parseInt(dayFilter)] || dayFilter);
          if (parts.length === 0) return null;
          return <div style={{ padding: "0 20px 6px", fontSize: 10, color: "#A89BB0", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{parts.join(" · ")}</div>;
        })()}
      </div>

      {/* Guided prompt — "What kind of day?" */}
      {!search && !showFavourites && dayFilter === "today" && weatherMode === "all" && !freeOnly && typeFilter === "All Types" && napFilter === "all" && (
        <div style={{ padding: "6px 20px 10px" }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: "#5C4B6B", marginBottom: 8 }}>What kind of day are we having?</div>
          <div style={{ display: "flex", gap: 8 }}>
            {[
              { label: "🏠 Stay dry", action: () => setWeatherMode("rainy") },
              { label: "☀️ Burn energy", action: () => setWeatherMode("sunny") },
              { label: "🎉 Free only", action: () => setFreeOnly(true) },
              { label: "✨ Surprise us", action: () => { setSortBy("mixed"); setDayFilter("all"); } },
            ].map(b => (
              <div key={b.label} onClick={() => { if (navigator.vibrate) navigator.vibrate(8); b.action(); }} style={{ flex: 1, padding: "8px 4px", background: "white", borderRadius: 12, border: "1px solid #EDE8E3", textAlign: "center", cursor: "pointer", fontSize: 11, fontWeight: 600, color: "#5C4B6B", lineHeight: 1.3 }}>{b.label}</div>
            ))}
          </div>
        </div>
      )}

      {/* Quick filters — one row */}
      <div style={{ display: "flex", gap: 6, padding: "0 20px 6px", overflowX: "auto" }}>
        {favourites.length > 0 && <Chip active={showFavourites} onClick={() => { setShowFavourites(!showFavourites); setPage(1); }} activeBg="#E8917A">❤️ Saved ({favourites.length})</Chip>}
        <Chip active={false} onClick={openCalendar} activeBg="#7B68EE">📅 My Plans {calendarTotal > 0 ? `(${calendarTotal})` : ""}</Chip>
        <Chip active={mapView} onClick={() => { setMapView(!mapView); if (!mapView && locStatus === "idle") requestLocation(); if (!mapView) setAreaFilter("All Areas"); }} activeBg="#E8917A">🗺️ Map</Chip>
        <Chip active={showMoreFilters} onClick={() => setShowMoreFilters(!showMoreFilters)} activeBg="#6B7394">🎛️ Filters</Chip>
      </div>

      {/* Expandable extra filters */}
      {showMoreFilters && (
        <div style={{ display: "flex", gap: 6, padding: "0 20px 6px", overflowX: "auto", flexWrap: "wrap" }}>
          <Chip active={weatherMode === "rainy"} onClick={() => setWeatherMode(weatherMode === "rainy" ? "all" : "rainy")} activeBg="#42A5F5">🌧️ Rainy Day</Chip>
          <Chip active={weatherMode === "sunny"} onClick={() => setWeatherMode(weatherMode === "sunny" ? "all" : "sunny")} activeBg="#FF9800">☀️ Sunny Day</Chip>
          <Chip active={napFilter === "morning"} onClick={() => setNapFilter(napFilter === "morning" ? "all" : "morning")} activeBg="#7B68EE">🌅 Morning</Chip>
          <Chip active={napFilter === "afternoon"} onClick={() => setNapFilter(napFilter === "afternoon" ? "all" : "afternoon")} activeBg="#7B68EE">🌙 Afternoon</Chip>
          {Object.keys(typeColors).map(t => (
            <Chip key={t} active={typeFilter === t} onClick={() => setTypeFilter(typeFilter === t ? "All Types" : t)} activeBg={typeColors[t].color}>{t}</Chip>
          ))}
        </div>
      )}

      {/* Active filters — clear all */}
      {(cityFilter !== "All" || dayFilter !== "today" || weatherMode !== "all" || napFilter !== "all" || freeOnly || typeFilter !== "All Types" || areaFilter !== "All Areas" || showFavourites) && (
        <div style={{ padding: "0 20px 6px" }}>
          <span onClick={() => { setCityFilter("All"); setDayFilter("today"); setWeatherMode("all"); setNapFilter("all"); setFreeOnly(false); setTypeFilter("All Types"); setAreaFilter("All Areas"); setSearch(""); setSortBy("mixed"); setPage(1); setShowFavourites(false); }} style={{ fontSize: 11, color: "#E8917A", fontWeight: 600, cursor: "pointer" }}>Clear all filters ✕</span>
        </div>
      )}

      {/* Map View */}
      {mapView && (
        <div style={{ margin: "0 20px 4px" }}>
          <div style={{ fontSize: 10, color: "#A89BB0", marginBottom: 4, textAlign: "right" }}>{filtered.filter(i => i.lat && i.lng).length} activities on map</div>
          <MapView filtered={filtered} userLoc={userLoc} onSelect={openDetail} />
        </div>
      )}

      {/* Listings — paginated */}
      {!mapView && <>
      {/* Featured Today — single hero pick */}
      {areaFilter === "Ealing" && cityFilter === "All" && dayFilter === "today" && weatherMode === "all" && napFilter === "all" && !freeOnly && typeFilter === "All Types" && !search && !showFavourites && filtered.length >= 1 && page === 1 && (() => {
        const isOutdoorItem = (item) => !item.indoor || item.type === "Outdoor";
        let featured;
        if (isSunny) {
          featured = filtered.find(i => isOutdoorItem(i)) || filtered[0];
        } else {
          featured = filtered.find(i => !isOutdoorItem(i)) || filtered[0];
        }
        if (!featured) return null;
        const tc = typeColors[featured.type] || { bg: "#eee", color: "#333" };
        const dist = userLoc && featured.lat ? Math.sqrt(Math.pow((featured.lat - userLoc.lat) * 111, 2) + Math.pow((featured.lng - userLoc.lng) * 111 * Math.cos(userLoc.lat * Math.PI / 180), 2)) * 0.621371 : null;
        const distMins = dist !== null ? (dist < 0.2 ? "right here" : dist < 1 ? Math.round(dist * 20) + " mins away" : dist.toFixed(1) + " mi away") : null;
        const reasons = [];
        if (featured.free) reasons.push("Free");
        if (!featured.indoor && isSunny) reasons.push("Outdoor fun");
        if (featured.indoor && !isSunny) reasons.push("Stay dry indoors");
        if (distMins) reasons.push(distMins);
        if (featured.day === "Daily" || featured.time && featured.time.includes("All")) reasons.push("Open all day");
        else if (isOnToday(featured)) reasons.push("On today");
        if (featured.verified) reasons.push("Parent favourite");
        const reasonLine = reasons.length > 0 ? reasons.slice(0, 3).join(" · ") : "";
        return (
        <div style={{ padding: "0 20px 10px" }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: "#A89BB0", marginBottom: 6, display: "flex", alignItems: "center", gap: 6 }}>
            <span style={{ fontSize: 9, fontWeight: 800, padding: "2px 8px", borderRadius: 6, background: "linear-gradient(135deg, #E8917A, #F0B89A)", color: "white", textTransform: "uppercase", letterSpacing: 0.5 }}>Featured</span>
            {isSunny ? "☀️ Perfect for today" : "🌧️ Great for a rainy day"}
          </div>
          <div onClick={() => openDetail(featured)} style={{ background: `linear-gradient(135deg, ${tc.bg}22, #FFFBF8)`, borderRadius: 18, padding: 18, border: "2px solid " + tc.color + "44", cursor: "pointer", position: "relative", overflow: "hidden", boxShadow: "0 4px 20px rgba(232,145,122,0.10)" }}>
            <div style={{ display: "flex", gap: 14, alignItems: "flex-start" }}>
              <div style={{ width: 72, height: 72, borderRadius: 16, background: `linear-gradient(135deg, ${tc.bg}, ${tc.bg}dd)`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 32, flexShrink: 0 }}>{featured.emoji || "🎉"}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 16, fontWeight: 800, color: "#5C4B6B", marginBottom: 3, lineHeight: 1.3 }}>{featured.name}</div>
                <div style={{ fontSize: 11, color: "#6B7394", marginBottom: 3 }}>{featured.type} · {featured.ages} · {featured.day}</div>
                <div style={{ fontSize: 11, color: "#6B7394", display: "flex", alignItems: "center", gap: 4, flexWrap: "wrap" }}>
                  📍 {featured.venue.split(",")[0]}, {featured.location}
                  {dist !== null && <span style={{ color: "#E8917A", fontWeight: 700 }}>· {dist < 0.2 ? "Right here!" : dist < 1 ? Math.round(dist * 20) + " min walk" : dist.toFixed(1) + " mi"}</span>}
                </div>
                <div style={{ marginTop: 6, display: "flex", alignItems: "center", gap: 8 }}>
                  <span style={{ fontSize: 13, fontWeight: 800, padding: "4px 12px", borderRadius: 8, background: featured.free ? "#E0F7F4" : "#FFF0E0", color: featured.free ? "#0D9488" : "#D35400" }}>{featured.price}</span>
                  {featured.verified && <span style={{ fontSize: 9, color: "#E8917A", fontWeight: 600 }}>★ Loved by local parents</span>}
                </div>
              </div>
            </div>
            {reasonLine && <div style={{ marginTop: 10, padding: "6px 10px", background: "linear-gradient(135deg, #FFF7F2, #FFF0E8)", borderRadius: 10, fontSize: 11, fontWeight: 600, color: "#C4956A", lineHeight: 1.4 }}>👉 Great pick today — {reasonLine}</div>}
            <div style={{ marginTop: 8, fontSize: 12, color: "#6B7394", lineHeight: 1.5 }}>{featured.description.slice(0, 100)}...</div>
            <div style={{ marginTop: 8, textAlign: "right" }}>
              <span style={{ fontSize: 11, fontWeight: 700, color: "#E8917A" }}>View details →</span>
            </div>
          </div>
        </div>
        );
      })()}
      {(() => {
        const isFeaturedContext = areaFilter === "Ealing" && cityFilter === "All" && dayFilter === "today" && weatherMode === "all" && napFilter === "all" && !freeOnly && typeFilter === "All Types" && !search && !showFavourites && filtered.length >= 1;
        const showFeatured = isFeaturedContext && page === 1;
        const pagedList = isFeaturedContext
          ? filtered.slice(1 + (page - 1) * 6, 1 + page * 6)
          : filtered.slice((page - 1) * 6, page * 6);
        return (
      <div style={{ padding: "0 20px 20px" }}>
        {filtered.length === 0 ? (
          <div style={{ textAlign: "center", padding: "40px 20px", color: "#6B7394" }}>
            <div style={{ fontSize: 44, marginBottom: 10 }}>{weatherMode === "rainy" ? "🌧️" : weatherMode === "sunny" ? "☀️" : "🔍"}</div>
            <div style={{ fontSize: 15, fontWeight: 700, color: "#5C4B6B", marginBottom: 4 }}>{areaFilter !== "All Areas" ? `Nothing found in ${areaFilter}` : dayFilter === "today" ? `Nothing found for ${todayName}` : "No activities match your filters"}</div>
            <div style={{ fontSize: 12, color: "#A89BB0", marginBottom: 16, lineHeight: 1.5 }}>{areaFilter !== "All Areas" ? "Try a different area or broaden your filters" : "Try fewer filters or search for something else"}</div>
            <div onClick={() => { setCityFilter("All"); setAreaFilter("All Areas"); setDayFilter("today"); setWeatherMode("all"); setNapFilter("all"); setFreeOnly(false); setTypeFilter("All Types"); setSearch(""); setSortBy("mixed"); setPage(1); setShowFavourites(false); }} style={{ display: "inline-block", padding: "10px 24px", background: "linear-gradient(135deg, #E8917A, #F0B89A)", color: "white", borderRadius: 12, fontSize: 13, fontWeight: 700, cursor: "pointer" }}>Reset all filters</div>
          </div>
        ) : (
          <>
          {page === 1 && <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
            <div style={{ flex: 1, height: 1, background: "#EDE8E3" }} />
            <span style={{ fontSize: 10, fontWeight: 700, color: "#A89BB0", letterSpacing: 0.5, textTransform: "uppercase" }}>Loved by {areaFilter !== "All Areas" ? areaFilter : "Ealing"} parents</span>
            <div style={{ flex: 1, height: 1, background: "#EDE8E3" }} />
          </div>}
          {pagedList.map((item, idx) => {
            const isNew = item.createdAt ? (Date.now() - new Date(item.createdAt).getTime()) < 14 * 24 * 60 * 60 * 1000 : false;
            return <React.Fragment key={item.id}>
              <ListingCard item={item} onSelect={openDetail} userLoc={userLoc} isFav={favourites.includes(item.id)} onToggleFav={toggleFavourite} isNew={isNew} reviews={reviews} />
              {idx === Math.min(5, pagedList.length - 1) && !showSuggest && !suggestSubmitted && page === 1 && (
                <div onClick={openSuggest} style={{ margin: "6px 0 8px", padding: "12px 16px", background: "linear-gradient(135deg, #FFF7F0, #FDDDE6)", borderRadius: 14, display: "flex", alignItems: "center", gap: 10, cursor: "pointer", border: "1.5px dashed #E8917A" }}>
                  <span style={{ fontSize: 22 }}>✨</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 14, fontWeight: 800, color: "#5C4B6B" }}>Know a hidden gem?</div>
                    <div style={{ fontSize: 11, color: "#A89BB0" }}>Help other parents discover great activities</div>
                  </div>
                  <span style={{ fontSize: 12, fontWeight: 800, color: "white", padding: "6px 14px", background: "linear-gradient(135deg, #E8917A, #F0B89A)", borderRadius: 10 }}>Add</span>
                </div>
              )}
            </React.Fragment>;
          })}
          </>
        )}
      </div>
        );
      })()}

      {/* Suggested Activities — horizontal scroll, clickable to listing */}
      {(() => {
        // Show suggested activities from Supabase suggestions table, plus recent Ealing listings as "parent picks"
        const parentPicks = listings.filter(l => l.location === "Ealing" && l.verified).slice(-8).reverse();
        const suggestedChips = suggestedActivities.length > 0 ? suggestedActivities : [];
        const allChips = [...suggestedChips.map(s => ({ id: "s-" + s.id, name: s.name, type: s.type, match: listings.find(l => l.name.toLowerCase().trim() === s.name.toLowerCase().trim()) })), ...parentPicks.filter(p => !suggestedChips.some(s => s.name.toLowerCase().trim() === p.name.toLowerCase().trim())).map(p => ({ id: "p-" + p.id, name: p.name, type: p.type, match: p }))];
        if (allChips.length === 0) return null;
        return (
        <div style={{ padding: "0 0 6px" }}>
          <div style={{ fontSize: 10, fontWeight: 600, marginBottom: 4, color: "#C4B8CB", paddingLeft: 20 }}>✨ Suggested & added by parents</div>
          <div style={{ display: "flex", gap: 6, overflowX: "auto", paddingLeft: 20, paddingRight: 20 }}>
            {allChips.slice(0, 10).map(c => (
              <div key={c.id} onClick={() => { if (c.match) openDetail(c.match); }} style={{ flexShrink: 0, padding: "5px 10px", background: "white", borderRadius: 8, border: "1px dashed #F0D5C0", cursor: c.match ? "pointer" : "default", maxWidth: 140 }}>
                <div style={{ fontSize: 9, fontWeight: 700, color: c.match ? "#E8917A" : "#5C4B6B", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{c.name}</div>
                <div style={{ fontSize: 8, color: "#C4B8CB" }}>{c.type}</div>
              </div>
            ))}
          </div>
        </div>
        );
      })()}

      {/* Pagination controls */}
      {(() => {
        const hasFeatured = areaFilter === "Ealing" && cityFilter === "All" && dayFilter === "today" && weatherMode === "all" && napFilter === "all" && !freeOnly && typeFilter === "All Types" && !search && !showFavourites && filtered.length >= 1;
        const mainCount = hasFeatured ? filtered.length - 1 : filtered.length;
        const totalPages = Math.ceil(mainCount / 6);
        if (totalPages <= 1) return null;
        return (
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 6, padding: "0 20px 16px" }}>
            <button onClick={() => { setPage(p => Math.max(1, p - 1)); window.scrollTo({ top: 0, behavior: "smooth" }); }} disabled={page === 1} style={{ padding: "8px 14px", borderRadius: 10, border: "1px solid #E0DBD5", background: page === 1 ? "#F5F0EB" : "white", color: page === 1 ? "#C4B8CB" : "#5C4B6B", fontSize: 12, fontWeight: 600, cursor: page === 1 ? "default" : "pointer", fontFamily: "inherit" }}>← Prev</button>
            <div style={{ display: "flex", gap: 4 }}>
              {Array.from({ length: totalPages }, (_, i) => i + 1).filter(p => p === 1 || p === totalPages || Math.abs(p - page) <= 1).map((p, idx, arr) => (
                <React.Fragment key={p}>
                  {idx > 0 && arr[idx - 1] < p - 1 && <span style={{ color: "#C4B8CB", fontSize: 12, padding: "0 2px" }}>...</span>}
                  <button onClick={() => { setPage(p); window.scrollTo({ top: 0, behavior: "smooth" }); }} style={{ width: 32, height: 32, borderRadius: 8, border: page === p ? "none" : "1px solid #E0DBD5", background: page === p ? "linear-gradient(135deg, #E8917A, #F0B89A)" : "white", color: page === p ? "white" : "#6B7394", fontSize: 12, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" }}>{p}</button>
                </React.Fragment>
              ))}
            </div>
            <button onClick={() => { setPage(p => Math.min(totalPages, p + 1)); window.scrollTo({ top: 0, behavior: "smooth" }); }} disabled={page === totalPages} style={{ padding: "8px 14px", borderRadius: 10, border: "1px solid #E0DBD5", background: page === totalPages ? "#F5F0EB" : "white", color: page === totalPages ? "#C4B8CB" : "#5C4B6B", fontSize: 12, fontWeight: 600, cursor: page === totalPages ? "default" : "pointer", fontFamily: "inherit" }}>Next →</button>
          </div>
        );
      })()}
      </>}

      <div style={{ textAlign: "center", padding: "8px 20px 8px", fontSize: 11, color: "#C4B8CB" }}>
        community-powered kids activity discovery 🧡
      </div>

      <div style={{ textAlign: "center", padding: "0 20px 24px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 6, marginBottom: 4 }}>
          <div style={{ width: 34, height: 34, borderRadius: 10, overflow: "hidden" }}><BrandBear size={34} /></div>
          <span style={{ fontSize: 16, fontWeight: 800, color: "#5C4B6B" }}>LITTLE<span style={{ color: "#E8917A" }}>locals</span></span>
        </div>
        <div style={{ fontSize: 10, color: "#D4CADE" }}>made with love by parents, for parents 🧡</div>
        {showInstallBanner && <div style={{ height: 44 }} />}
      </div>

      </>}

      {/* Floating "Top" button */}
      {showScrollTop && (
        <div onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} style={{ position: "fixed", bottom: showInstallBanner ? 60 : 20, right: 16, padding: "8px 12px", background: "white", borderRadius: 12, border: "1px solid #E0DBD5", boxShadow: "0 4px 12px rgba(0,0,0,0.08)", cursor: "pointer", fontSize: 12, fontWeight: 700, color: "#5C4B6B", zIndex: 998, transition: "bottom 0.2s" }}>↑ Top</div>
      )}

      {/* Add to Home Screen Banner */}
      {showInstallBanner && (
        <div style={{ position: "fixed", bottom: 0, left: 0, right: 0, background: "white", zIndex: 999, borderTop: "1px solid #F0EBE6" }}>
          {/iPhone|iPad|iPod/.test(navigator.userAgent) ? (
            <div style={{ padding: "12px 16px" }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 6 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <img src="/bear-logo.png" alt="LITTLElocals" style={{ width: 28, height: 28, borderRadius: 6 }} />
                  <span style={{ fontSize: 12, fontWeight: 800, color: "#5C4B6B" }}>Save as an app!</span>
                </div>
                <div onClick={() => { setShowInstallBanner(false); try { localStorage.setItem("ll_install_dismissed", "1"); } catch(e) {} }} style={{ fontSize: 11, color: "#A89BB0", cursor: "pointer", padding: "4px 8px" }}>✕</div>
              </div>
              <div style={{ fontSize: 11, color: "#6B7394", lineHeight: 1.5 }}>
                Tap <span style={{ display: "inline-block", padding: "1px 6px", background: "#F0EBE6", borderRadius: 4, fontWeight: 700 }}>⬆ Share</span> at the bottom of Safari, then tap <span style={{ display: "inline-block", padding: "1px 6px", background: "#F0EBE6", borderRadius: 4, fontWeight: 700 }}>＋ Add to Home Screen</span>
              </div>
            </div>
          ) : (
            <div style={{ padding: "10px 16px", display: "flex", alignItems: "center", gap: 10 }}>
              <img src="/bear-logo.png" alt="LITTLElocals" style={{ width: 28, height: 28, borderRadius: 6 }} />
              <div onClick={async () => { if (installPrompt) { installPrompt.prompt(); const result = await installPrompt.userChoice; if (result.outcome === "accepted") { setShowInstallBanner(false); try { localStorage.setItem("ll_install_dismissed", "1"); } catch(e) {} } setInstallPrompt(null); } }} style={{ flex: 1, fontSize: 11, color: "#5C4B6B", cursor: "pointer" }}>
                <span style={{ fontWeight: 700 }}>{installPrompt ? "Tap to install app" : "Add to home screen"}</span> for quick access
              </div>
              <div onClick={() => { setShowInstallBanner(false); try { localStorage.setItem("ll_install_dismissed", "1"); } catch(e) {} }} style={{ fontSize: 11, color: "#A89BB0", cursor: "pointer", padding: "4px 8px" }}>✕</div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}


export default WestLondonListings;
