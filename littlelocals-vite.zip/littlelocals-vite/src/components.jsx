import React, { useState, useEffect, useRef } from "react";
import { typeColors } from "./typeColors";
import { dayMap } from "./typeColors";
import { sceneIllustrations } from "./utils";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { getDistanceMiles } from "./utils";

export function BrandBear({ size = 38 }) {
  return (
    <img src="/bear-logo.png" alt="LITTLElocals" style={{ width: size, height: size, borderRadius: size * 0.2, objectFit: "cover" }} />
  );
}

export function SceneBg({ type, w, h }) {
  const renderer = sceneIllustrations[type];
  return renderer ? renderer(w, h) : null;
}

export function isOnToday(item) {
  const today = new Date().getDay();
  const days = dayMap[item.day];
  return days ? days.includes(today) : true;
}

export function isOnDay(item, dayNum) {
  if (dayNum === -1) return true; // "All Days"
  const days = dayMap[item.day];
  return days ? days.includes(dayNum) : true;
}

export function shareWhatsApp(item) {
  var e = function(c) { return String.fromCodePoint(c); };
  var bear = e(0x1F9F8);
  var pin = e(0x1F4CD);
  var cal = e(0x1F4C5);
  var heart = e(0x1F9E1);
  var down = e(0x1F447);
  var dot = e(0x00B7);
  var text = "Check out " + item.name + "! " + bear + "\n\n" + item.type + " " + dot + " " + item.ages + " " + dot + " " + item.price + "\n" + pin + " " + item.venue + "\n" + cal + " " + item.day + " " + item.time + "\n\n" + item.description.slice(0,120) + "...\n\nFound on LITTLElocals " + heart + "\nDiscover more activities for your little ones " + down + "\nhttps://littlelocals.uk";
  window.open("https://wa.me/?text=" + encodeURIComponent(text), "_blank");
}

export function MapView({ filtered, userLoc, onSelect }) {
  const mapRef = useRef(null);
  const mapObjRef = useRef(null);
  
  

  

  useEffect(function() {
    if (!mapRef.current) return;
    var cancelled = false;
    var timer = setTimeout(function() {
      if (cancelled || !mapRef.current) return;
      try {
        // Clean up any existing map
        if (mapObjRef.current) {
          try { mapObjRef.current.remove(); } catch(e) {}
          mapObjRef.current = null;
        }
        // Clear Leaflet internal state from container
        var el = mapRef.current;
        if (el._leaflet_id) {
          delete el._leaflet_id;
          el.innerHTML = "";
        }
        var center = userLoc ? [userLoc.lat, userLoc.lng] : [51.513, -0.309];
        var map = L.map(el, { zoomControl: false }).setView(center, 13);
        L.control.zoom({ position: "bottomright" }).addTo(map);
        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { attribution: "" }).addTo(map);
        if (userLoc) {
          var youIcon = L.divIcon({ className: "", html: "<div style='width:14px;height:14px;background:#E8917A;border:3px solid white;border-radius:50%;box-shadow:0 2px 6px rgba(0,0,0,0.3)'></div>", iconSize: [20, 20], iconAnchor: [10, 10] });
          L.marker([userLoc.lat, userLoc.lng], { icon: youIcon }).addTo(map).bindPopup("<b>You are here</b>");
        }
        var bounds = [];
        filtered.forEach(function(item) {
          if (!item.lat || !item.lng) return;
          var pinIcon = L.divIcon({ className: "", html: "<div style='font-size:20px;text-shadow:0 2px 4px rgba(0,0,0,0.3)'>" + (item.emoji || "📍") + "</div>", iconSize: [28, 28], iconAnchor: [14, 28] });
          var marker = L.marker([item.lat, item.lng], { icon: pinIcon }).addTo(map);
          var dist = userLoc ? (Math.sqrt(Math.pow((item.lat - userLoc.lat) * 111, 2) + Math.pow((item.lng - userLoc.lng) * 111 * Math.cos(userLoc.lat * Math.PI / 180), 2))).toFixed(1) : null;
          var postcode = item.venue ? item.venue.match(/[A-Z]{1,2}\d[\dA-Z]?\s?\d[A-Z]{2}/i) : null;
          var locLine = postcode ? postcode[0] : (item.venue || "");
          var popupHtml = "<div style='min-width:150px;font-family:system-ui,sans-serif'>" +
            "<div style='font-size:13px;font-weight:700;color:#5C4B6B;margin-bottom:4px'>" + (item.emoji || "") + " " + item.name + "</div>" +
            "<div style='font-size:10px;color:#6B7394;margin-bottom:2px'>" + item.type + " - " + (item.ages || "") + "</div>" +
            "<div style='font-size:10px;color:#6B7394;margin-bottom:2px'>" + (item.day || "") + " " + (item.time || "") + "</div>" +
            "<div style='font-size:10px;color:#6B7394;margin-bottom:2px'>📍 " + locLine + "</div>" +
            (dist ? "<div style='font-size:10px;color:#E8917A;font-weight:600;margin-bottom:2px'>" + dist + " km away</div>" : "") +
            "<div style='font-size:11px;font-weight:700;color:#5C4B6B;margin-bottom:5px'>" + (item.price || "") + "</div>" +
            "<div id='ll-map-" + item.id + "' style='font-size:11px;color:white;font-weight:700;cursor:pointer;background:linear-gradient(135deg,#E8917A,#F0B89A);padding:6px 10px;border-radius:8px;text-align:center'>View details →</div>" +
            "</div>";
          marker.bindPopup(popupHtml);
          marker.on("popupopen", function() {
            var link = document.getElementById("ll-map-" + item.id);
            if (link) link.onclick = function() { onSelect(item); };
          });
          bounds.push([item.lat, item.lng]);
        });
        if (userLoc) bounds.push([userLoc.lat, userLoc.lng]);
        if (bounds.length > 1) map.fitBounds(bounds, { padding: [40, 40], maxZoom: 14 });
        else if (bounds.length === 1) map.setView(bounds[0], 14);
        mapObjRef.current = map;
        setTimeout(function() { if (map && map._container) map.invalidateSize(); }, 300);
      } catch(e) { console.error("Map error:", e); }
    }, 100);
    return function() {
      cancelled = true;
      clearTimeout(timer);
      try { if (mapObjRef.current) { mapObjRef.current.remove(); mapObjRef.current = null; } } catch(e) {}
    };
  }, [filtered.length, userLoc]);

  return <div ref={mapRef} style={{ height: 380, borderRadius: 16, border: "1px solid #F0E8E0", overflow: "hidden" }} />;
}

export function ListingCard({ item, onSelect, userLoc, isFav, onToggleFav, isNew, reviews }) {
  const tc = typeColors[item.type] || { bg: "#eee", color: "#333" };
  const dist = userLoc ? getDistanceMiles(userLoc.lat, userLoc.lng, item.lat, item.lng) : null;
  const onToday = isOnToday(item);
  return (
    <div style={{ display: "flex", gap: 12, padding: "14px 0", borderBottom: "1px solid #F0EBE6", cursor: "pointer", position: "relative" }}>
      <div onClick={() => onSelect(item)} style={{ width: 64, height: 64, borderRadius: 14, background: `linear-gradient(135deg, ${tc.bg}, ${tc.bg}ee)`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 28, flexShrink: 0, position: "relative", overflow: "hidden", boxShadow: "0 2px 8px rgba(0,0,0,0.06)" }}>
        <SceneBg type={item.type} w={64} h={64} />
        <span style={{ position: "relative", zIndex: 2, filter: "drop-shadow(0 1px 2px rgba(0,0,0,0.1))" }}>{item.emoji}</span>
        {onToday && <div style={{ position: "absolute", top: -1, right: -1, width: 16, height: 16, background: "#2EC4B6", borderRadius: "0 14px 0 8px", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 3 }}><span style={{ fontSize: 8, color: "white" }}>✓</span></div>}
      </div>
      <div onClick={() => onSelect(item)} style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 2, display: "flex", alignItems: "center", gap: 6 }}>
          {item.name}
          {isNew && <span style={{ fontSize: 9, fontWeight: 700, padding: "2px 6px", borderRadius: 6, background: "linear-gradient(135deg, #E8917A, #F0B89A)", color: "white", flexShrink: 0 }}>NEW</span>}
        </div>
        <div style={{ fontSize: 11, color: "#6B7394", lineHeight: 1.4 }}>{item.type} · {item.ages} · {item.day}</div>
        <div style={{ fontSize: 11, color: "#6B7394", display: "flex", alignItems: "center", gap: 4, flexWrap: "wrap" }}>
          📍 {item.venue.split(",")[0]}, {item.location}
          {dist !== null && <span style={{ color: "#E8917A", fontWeight: 700 }}>· {dist < 0.2 ? "Right here!" : dist < 1 ? Math.round(dist * 20) + " min walk" : dist.toFixed(1) + " mi"}</span>}
        </div>
      </div>
      <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 4, flexShrink: 0 }}>
        <span onClick={(e) => { e.stopPropagation(); onToggleFav(item.id); }} style={{ fontSize: 20, cursor: "pointer", lineHeight: 1, transition: "transform 0.2s", transform: isFav ? "scale(1.1)" : "scale(1)" }}>{isFav ? "🧡" : "🤍"}</span>
        <span style={{ fontSize: 12, fontWeight: 800, padding: "4px 10px", borderRadius: 8, background: item.free ? "#E0F7F4" : "#FFF0E0", color: item.free ? "#0D9488" : "#D35400" }}>{item.price}</span>
        {item.verified && <span style={{ fontSize: 9, color: "#E8917A", fontWeight: 600 }}>★ Loved by local parents</span>}
        {(() => { const r = reviews.filter(rv => rv.listingId === item.id); if (r.length === 0) return null; const avg = (r.reduce((s, rv) => s + rv.rating, 0) / r.length).toFixed(1); return <span style={{ fontSize: 9, color: "#C4956A" }}>⭐ {avg} ({r.length})</span>; })()}
      </div>
    </div>
  );
}

export function DetailView({ item, onBack, userLoc, reviews, onAddReview, isFav, onToggleFav, onAddToCalendar, calendarPlan, isVisited, onToggleVisited }) {
  const tc = typeColors[item.type] || { bg: "#eee", color: "#333" };
  const dist = userLoc ? getDistanceMiles(userLoc.lat, userLoc.lng, item.lat, item.lng) : null;
  const itemReviews = reviews.filter(r => r.listingId === item.id);
  const avgRating = itemReviews.length > 0 ? (itemReviews.reduce((s, r) => s + r.rating, 0) / itemReviews.length).toFixed(1) : null;
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [reviewName, setReviewName] = useState("");
  const [reviewText, setReviewText] = useState("");
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewImages, setReviewImages] = useState([]);
  const [submitted, setSubmitted] = useState(false);

  const handleImageUpload = (e) => {
    const files = Array.from(e.target.files);
    files.forEach(file => {
      const reader = new FileReader();
      reader.onload = (ev) => setReviewImages(prev => [...prev, ev.target.result]);
      reader.readAsDataURL(file);
    });
  };

  const submitReview = () => {
    if (!reviewName.trim() || !reviewText.trim()) return;
    onAddReview({
      id: Date.now(),
      listingId: item.id,
      name: reviewName.trim(),
      text: reviewText.trim(),
      rating: reviewRating,
      images: reviewImages,
      date: new Date().toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }),
    });
    setReviewName(""); setReviewText(""); setReviewRating(5); setReviewImages([]); setShowReviewForm(false); setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
  };

  return (
    <div style={{ flex: 1, overflowY: "auto" }}>
      <div style={{ height: 190, background: `linear-gradient(135deg, ${tc.bg}, ${tc.bg}dd, white)`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 64, position: "relative", overflow: "hidden" }}>
        <SceneBg type={item.type} w={500} h={190} />
        <span style={{ position: "relative", zIndex: 2, filter: "drop-shadow(0 2px 8px rgba(0,0,0,0.12))" }}>{item.emoji}</span>
        <div onClick={onBack} style={{ position: "absolute", top: 12, left: 12, padding: "6px 12px", background: "rgba(255,255,255,0.95)", borderRadius: 20, display: "flex", alignItems: "center", gap: 4, cursor: "pointer", fontSize: 13, fontWeight: 700, color: "#5C4B6B", zIndex: 3, boxShadow: "0 2px 8px rgba(0,0,0,0.12)" }}>← Back</div>
        <div style={{ position: "absolute", top: 12, right: 12, display: "flex", gap: 8, zIndex: 3 }}>
          <div onClick={() => onToggleFav(item.id)} style={{ width: 36, height: 36, background: "rgba(255,255,255,0.92)", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", fontSize: 18, boxShadow: "0 2px 8px rgba(0,0,0,0.1)" }}>{isFav ? "🧡" : "🤍"}</div>
          <div onClick={(e) => { e.stopPropagation(); shareWhatsApp(item); }} style={{ width: 36, height: 36, background: "#25D366", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", fontSize: 16, color: "white", fontWeight: 700, boxShadow: "0 2px 8px rgba(0,0,0,0.15)" }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="white"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/><path d="M12 0C5.373 0 0 5.373 0 12c0 2.625.846 5.059 2.284 7.034L.789 23.492a.75.75 0 00.917.918l4.462-1.496A11.945 11.945 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 22c-2.336 0-4.512-.684-6.34-1.861l-.455-.296-2.725.914.912-2.727-.306-.463A9.963 9.963 0 012 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z"/></svg>
        </div>
        </div>
        <div style={{ position: "absolute", bottom: 10, left: 12, display: "flex", gap: 6, flexWrap: "wrap", zIndex: 3 }}>
          <span style={{ padding: "3px 10px", borderRadius: 8, fontSize: 11, fontWeight: 700, color: "white", background: tc.color, boxShadow: "0 1px 4px rgba(0,0,0,0.15)" }}>{item.type}</span>
          <span style={{ padding: "3px 10px", borderRadius: 8, fontSize: 11, fontWeight: 700, color: "white", background: item.indoor ? "rgba(0,0,0,0.45)" : "#66BB6A", boxShadow: "0 1px 4px rgba(0,0,0,0.15)" }}>{item.indoor ? "Indoor 🌧️" : "Outdoor ☀️"}</span>
          {item.free && <span style={{ padding: "3px 10px", borderRadius: 8, fontSize: 11, fontWeight: 700, color: "white", background: "#2EC4B6", boxShadow: "0 1px 4px rgba(0,0,0,0.15)" }}>Free</span>}
          {isOnToday(item) && <span style={{ padding: "3px 10px", borderRadius: 8, fontSize: 11, fontWeight: 700, color: "white", background: "#FF6B6B", boxShadow: "0 1px 4px rgba(0,0,0,0.15)" }}>On Today!</span>}
        </div>
      </div>
      <div style={{ padding: 20 }}>
        <div style={{ fontSize: 20, fontWeight: 800, marginBottom: 4, display: "flex", alignItems: "center", gap: 8 }}>
          {item.name}
          {avgRating && <span style={{ fontSize: 12, fontWeight: 700, padding: "2px 8px", borderRadius: 8, background: "#FFF3E0", color: "#E67E22" }}>⭐ {avgRating}</span>}
        </div>
        <div style={{ fontSize: 12, color: tc.color, fontWeight: 600, marginBottom: 14, display: "flex", alignItems: "center", gap: 4 }}>
          📍 {item.location}{dist !== null && <span style={{ color: "#FF6B6B" }}>· {dist.toFixed(1)} miles away</span>}
          {item.verified && <span style={{ display: "inline-flex", width: 16, height: 16, background: "#2EC4B6", borderRadius: "50%", alignItems: "center", justifyContent: "center", color: "white", fontSize: 9, fontWeight: 700 }}>✓</span>}
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 18 }}>
          {[
            { icon: "📅", label: "When", value: item.day },
            { icon: "🕐", label: "Time", value: item.time },
            { icon: "👶", label: "Ages", value: item.ages },
            { icon: "💷", label: "Price", value: item.price },
            { icon: "🅿️", label: "Parking", value: parkingLabels[item.parking]?.replace("🅿️ ", "") || "Check venue" },
            { icon: item.indoor ? "🏠" : "🌳", label: "Setting", value: item.indoor ? "Indoor" : "Outdoor" },
          ].map((i, idx) => (
            <div key={idx} style={{ background: "white", borderRadius: 10, padding: 10, display: "flex", alignItems: "center", gap: 8, border: "1px solid #F0EBE6" }}>
              <span style={{ fontSize: 18 }}>{i.icon}</span>
              <div>
                <div style={{ fontSize: 10, color: "#6B7394" }}>{i.label}</div>
                <div style={{ fontSize: 12, fontWeight: 700 }}>{i.value}</div>
              </div>
            </div>
          ))}
        </div>
        <p style={{ fontSize: 13, lineHeight: 1.7, color: "#6B7394", marginBottom: 16 }}>{item.description}</p>
        {item.photos && (
          <div onClick={(e) => { e.stopPropagation(); window.open(item.photos, "_blank"); }} style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8, padding: "12px 16px", background: "white", borderRadius: 12, border: "1px solid #F0EBE6", marginBottom: 16, cursor: "pointer", boxShadow: "0 2px 8px rgba(0,0,0,0.04)" }}>
            <span style={{ fontSize: 20 }}>📸</span>
            <div>
              <div style={{ fontSize: 13, fontWeight: 700, color: "#2D3142" }}>See Photos & Reviews</div>
              <div style={{ fontSize: 10, color: "#6B7394" }}>View real photos from visitors on {item.photos.includes("instagram") ? "Instagram" : item.photos.includes("facebook") ? "Facebook" : "Google Maps"}</div>
            </div>
            <span style={{ marginLeft: "auto", fontSize: 16, color: "#6B7394" }}>→</span>
          </div>
        )}
        <div style={{ background: "white", borderRadius: 10, padding: 12, display: "flex", alignItems: "center", gap: 10, border: "1px solid #F0EBE6", marginBottom: 16 }}>
          <span style={{ fontSize: 18 }}>📍</span>
          <div>
            <div style={{ fontSize: 12, fontWeight: 700 }}>{item.venue.split(",")[0]}</div>
            <div style={{ fontSize: 10, color: "#6B7394" }}>{item.venue}</div>
          </div>
        </div>
        {item.bring.length > 0 && (
          <>
            <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 8 }}>🎒 What to Bring</div>
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 16 }}>
              {item.bring.map(b => <span key={b} style={{ padding: "5px 10px", background: "#FFF3E0", borderRadius: 8, fontSize: 11, fontWeight: 600, color: "#E67E22" }}>{b}</span>)}
            </div>
          </>
        )}
        {item.sen && <div style={{ padding: "8px 12px", background: "#E8FBF8", borderRadius: 10, fontSize: 12, fontWeight: 600, color: "#2EC4B6", marginBottom: 16 }}>♿ SEN / Additional Needs Friendly</div>}

        {/* COMMUNITY REVIEWS SECTION */}
        <div style={{ marginBottom: 16 }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
            <div style={{ fontSize: 14, fontWeight: 700 }}>💬 Community Reviews {itemReviews.length > 0 && <span style={{ fontSize: 11, color: "#6B7394", fontWeight: 500 }}>({itemReviews.length})</span>}</div>
            {!showReviewForm && <span onClick={() => setShowReviewForm(true)} style={{ fontSize: 11, fontWeight: 700, color: "#FF6B6B", cursor: "pointer", padding: "4px 10px", background: "#FF6B6B12", borderRadius: 8 }}>+ Add Review</span>}
          </div>

          {submitted && (
            <div style={{ padding: "10px 14px", background: "#E8FBF8", borderRadius: 10, marginBottom: 12, fontSize: 12, fontWeight: 600, color: "#2EC4B6", textAlign: "center" }}>✓ Review added — thanks for helping other parents!</div>
          )}

          {/* Review Form */}
          {showReviewForm && (
            <div style={{ background: "white", borderRadius: 12, padding: 16, border: "1px solid #F0EBE6", marginBottom: 12, boxShadow: "0 2px 8px rgba(0,0,0,0.04)" }}>
              <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 12 }}>Share your experience</div>
              <input value={reviewName} onChange={e => setReviewName(e.target.value)} placeholder="Your first name" style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1px solid #E0DBD5", fontSize: 13, fontFamily: "inherit", marginBottom: 8, boxSizing: "border-box", outline: "none" }} />
              <div style={{ marginBottom: 8 }}>
                <div style={{ fontSize: 11, color: "#6B7394", marginBottom: 4 }}>Rating</div>
                <div style={{ display: "flex", gap: 4 }}>
                  {[1,2,3,4,5].map(s => (
                    <span key={s} onClick={() => setReviewRating(s)} style={{ fontSize: 24, cursor: "pointer", filter: s <= reviewRating ? "none" : "grayscale(1) opacity(0.3)" }}>⭐</span>
                  ))}
                </div>
              </div>
              <textarea value={reviewText} onChange={e => setReviewText(e.target.value)} placeholder="What did you and your little one think? Any tips for other parents?" rows={3} style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1px solid #E0DBD5", fontSize: 13, fontFamily: "inherit", marginBottom: 8, boxSizing: "border-box", resize: "vertical", outline: "none" }} />
              <div style={{ marginBottom: 10 }}>
                <label style={{ display: "flex", alignItems: "center", gap: 8, padding: "10px 12px", background: "#F8F6F3", borderRadius: 10, cursor: "pointer", border: "1px dashed #E0DBD5" }}>
                  <span style={{ fontSize: 18 }}>📷</span>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 600, color: "#2D3142" }}>Add photos</div>
                    <div style={{ fontSize: 10, color: "#6B7394" }}>Help other parents see what it's like</div>
                  </div>
                  <input type="file" accept="image/*" multiple onChange={handleImageUpload} style={{ display: "none" }} />
                </label>
                {reviewImages.length > 0 && (
                  <div style={{ display: "flex", gap: 6, marginTop: 8, overflowX: "auto" }}>
                    {reviewImages.map((img, i) => (
                      <div key={i} style={{ position: "relative", flexShrink: 0 }}>
                        <img src={img} alt="" style={{ width: 60, height: 60, borderRadius: 8, objectFit: "cover" }} />
                        <span onClick={() => setReviewImages(prev => prev.filter((_, idx) => idx !== i))} style={{ position: "absolute", top: -4, right: -4, width: 18, height: 18, background: "#FF6B6B", borderRadius: "50%", color: "white", fontSize: 10, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }}>✕</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              <div style={{ display: "flex", gap: 8 }}>
                <button onClick={() => { setShowReviewForm(false); setReviewImages([]); }} style={{ flex: 1, padding: 10, borderRadius: 10, border: "1px solid #E0DBD5", background: "white", fontSize: 12, fontWeight: 600, cursor: "pointer", fontFamily: "inherit", color: "#6B7394" }}>Cancel</button>
                <button onClick={submitReview} disabled={!reviewName.trim() || !reviewText.trim()} style={{ flex: 1.5, padding: 10, borderRadius: 10, border: "none", background: reviewName.trim() && reviewText.trim() ? "#FF6B6B" : "#E0DBD5", color: "white", fontSize: 12, fontWeight: 700, cursor: reviewName.trim() && reviewText.trim() ? "pointer" : "default", fontFamily: "inherit" }}>Post Review</button>
              </div>
            </div>
          )}

          {/* Existing Reviews */}
          {itemReviews.length > 0 ? itemReviews.map(r => (
            <div key={r.id} style={{ background: "white", borderRadius: 12, padding: 14, border: "1px solid #F0EBE6", marginBottom: 8 }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 6 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <div style={{ width: 30, height: 30, borderRadius: "50%", background: "linear-gradient(135deg, #FF6B6B, #7B68EE)", display: "flex", alignItems: "center", justifyContent: "center", color: "white", fontSize: 12, fontWeight: 700 }}>{r.name.charAt(0).toUpperCase()}</div>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 700 }}>{r.name}</div>
                    <div style={{ fontSize: 10, color: "#6B7394" }}>{r.date}</div>
                  </div>
                </div>
                <div style={{ fontSize: 11 }}>{"⭐".repeat(r.rating)}</div>
              </div>
              <p style={{ fontSize: 12, lineHeight: 1.6, color: "#6B7394", margin: 0 }}>{r.text}</p>
              {((r.images && r.images.length > 0) || (r.photos && r.photos.length > 0)) && (
                <div style={{ display: "flex", gap: 6, marginTop: 8, overflowX: "auto" }}>
                  {(r.images || r.photos).map((img, i) => <img key={i} src={img} alt="" style={{ width: 80, height: 80, borderRadius: 8, objectFit: "cover", flexShrink: 0 }} />)}
                </div>
              )}
            </div>
          )) : !showReviewForm && (
            <div style={{ textAlign: "center", padding: "16px 12px", background: "white", borderRadius: 12, border: "1px dashed #E0DBD5", color: "#6B7394" }}>
              <div style={{ fontSize: 24, marginBottom: 4 }}>💬</div>
              <div style={{ fontSize: 12, fontWeight: 600 }}>No reviews yet — be the first!</div>
              <div style={{ fontSize: 10, marginTop: 2 }}>Help other parents by sharing your experience</div>
            </div>
          )}
        </div>

        {/* Add to Calendar */}
        <div style={{ marginBottom: 12 }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: "#5C4B6B", marginBottom: 6 }}>📅 Add to My Plans</div>
          <div style={{ display: "flex", gap: 4, overflowX: "auto", paddingBottom: 4 }}>
            {Array.from({ length: 14 }, (_, i) => {
              const d = new Date(); d.setDate(d.getDate() + i);
              const dateKey = d.toISOString().split("T")[0];
              const isAdded = (calendarPlan[dateKey] || []).includes(item.id);
              const dayLabel = i === 0 ? "Today" : i === 1 ? "Tmrw" : d.toLocaleDateString("en-GB", { weekday: "short" });
              const dateLabel = d.getDate();
              return <div key={dateKey} onClick={() => !isAdded && onAddToCalendar(item.id, dateKey)} style={{ flexShrink: 0, padding: "6px 8px", borderRadius: 10, fontSize: 10, fontWeight: 700, textAlign: "center", minWidth: 44, background: isAdded ? "#E8917A" : "white", color: isAdded ? "white" : "#5C4B6B", border: `1px solid ${isAdded ? "#E8917A" : "#E0DBD5"}`, cursor: isAdded ? "default" : "pointer" }}>
                <div style={{ fontSize: 9, marginBottom: 2 }}>{dayLabel}</div>
                <div>{isAdded ? "✓" : dateLabel}</div>
              </div>;
            })}
          </div>
        </div>

        {/* Been There — Activity Passport */}
        <div onClick={() => onToggleVisited(item.id)} style={{ marginBottom: 12, padding: "10px 14px", borderRadius: 12, display: "flex", alignItems: "center", gap: 10, cursor: "pointer", background: isVisited ? "linear-gradient(135deg, #2EC4B6, #7BDDD5)" : "white", border: isVisited ? "none" : "1.5px dashed #E0DBD5" }}>
          <span style={{ fontSize: 20 }}>{isVisited ? "🏆" : "✅"}</span>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: isVisited ? "white" : "#5C4B6B" }}>{isVisited ? "Been There! 🎉" : "Been here? Tap to collect!"}</div>
            <div style={{ fontSize: 10, color: isVisited ? "rgba(255,255,255,0.8)" : "#A89BB0" }}>{isVisited ? "Added to your Activity Passport" : "Track activities your family has tried"}</div>
          </div>
          {isVisited && <span style={{ fontSize: 11, color: "white", fontWeight: 600 }}>✕ Undo</span>}
        </div>

        <div style={{ display: "flex", gap: 10 }}>
          <button onClick={(e) => { e.stopPropagation(); if (navigator.share) navigator.share({ title: item.name, url: item.cta.url }); else window.open("https://wa.me/?text=" + encodeURIComponent(item.name + " " + item.cta.url), "_blank"); }} style={{ flex: 1, padding: 12, borderRadius: 12, border: "none", background: "#25D366", color: "white", fontSize: 13, fontWeight: 700, cursor: "pointer", fontFamily: "inherit", display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="white"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/><path d="M12 0C5.373 0 0 5.373 0 12c0 2.625.846 5.059 2.284 7.034L.789 23.492a.75.75 0 00.917.918l4.462-1.496A11.945 11.945 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 22c-2.336 0-4.512-.684-6.34-1.861l-.455-.296-2.725.914.912-2.727-.306-.463A9.963 9.963 0 012 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z"/></svg>
            Share
          </button>
          <button onClick={(e) => { e.stopPropagation(); window.open(item.cta.url, "_blank"); }} style={{ flex: 1.2, padding: 12, borderRadius: 12, border: "none", background: item.cta.type === "phone" ? "#42A5F5" : item.cta.type === "facebook" ? "#1877F2" : item.cta.type === "email" ? "#7B68EE" : "#FF6B6B", color: "white", fontSize: 13, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" }}>
            {item.cta.type === "phone" ? "📞" : item.cta.type === "facebook" ? "📘" : item.cta.type === "email" ? "✉️" : "🌐"} {item.cta.label}
          </button>
        </div>
      </div>
    </div>
  );
}
